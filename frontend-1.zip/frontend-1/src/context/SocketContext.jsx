import { createContext, useContext, useEffect, useState } from 'react';
import socketService from '../services/socketService';
import { useToast } from './ToastContext';

const SocketContext = createContext(null);

export const useSocket = () => {
    const context = useContext(SocketContext);
    if (!context) {
        throw new Error('useSocket must be used within a SocketProvider');
    }
    return context;
};

export const SocketProvider = ({ children }) => {
    const [connected, setConnected] = useState(false);
    const { showToast } = useToast();

    useEffect(() => {
        // Get token from localStorage
        const token = localStorage.getItem('token');
        const user = localStorage.getItem('user');

        // Only connect if user is a restaurant owner
        if (token && user) {
            try {
                const userData = JSON.parse(user);
                if (userData.role === 'restaurant') {
                    // Connect to WebSocket
                    socketService.connect(token);
                    setConnected(true);

                    // Listen for connection events
                    socketService.on('connect', () => {
                        console.log('WebSocket connected');
                        setConnected(true);
                    });

                    socketService.on('disconnect', () => {
                        console.log('WebSocket disconnected');
                        setConnected(false);
                    });

                    socketService.on('connect_error', (error) => {
                        console.error('WebSocket connection error:', error);
                        setConnected(false);
                    });
                }
            } catch (error) {
                console.error('Error parsing user data:', error);
            }
        }

        // Cleanup on unmount
        return () => {
            socketService.disconnect();
        };
    }, []);

    const value = {
        socket: socketService,
        connected,
    };

    return (
        <SocketContext.Provider value={value}>
            {children}
        </SocketContext.Provider>
    );
};
