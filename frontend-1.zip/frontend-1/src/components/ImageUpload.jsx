import { useState } from 'react';
import { FaUpload, FaTrash, FaImage } from 'react-icons/fa';
import axios from 'axios';
import './ImageUpload.css';

const ImageUpload = ({ onImageUpload, currentImage, type = 'menu-item' }) => {
    const [uploading, setUploading] = useState(false);
    const [preview, setPreview] = useState(currentImage || null);
    const [error, setError] = useState(null);

    const handleFileSelect = async (e) => {
        const file = e.target.files[0];

        if (!file) return;

        // Validate file type
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            setError('Only JPEG, PNG, and WebP images are allowed');
            return;
        }

        // Validate file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            setError('File size must be less than 5MB');
            return;
        }

        setError(null);

        // Create preview
        const reader = new FileReader();
        reader.onloadend = () => {
            setPreview(reader.result);
        };
        reader.readAsDataURL(file);

        // Upload to server
        try {
            setUploading(true);

            const formData = new FormData();
            formData.append('image', file);

            if (type === 'restaurant') {
                const imageType = prompt('Enter image type (logo or banner):');
                if (!imageType || !['logo', 'banner'].includes(imageType)) {
                    setError('Invalid image type');
                    setUploading(false);
                    return;
                }
                formData.append('type', imageType);
            }

            const token = localStorage.getItem('token');
            const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

            const response = await axios.post(
                `${API_URL}/upload/${type}`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            if (response.data.success) {
                setPreview(response.data.data.url);
                onImageUpload(response.data.data);
            }
        } catch (err) {
            console.error('Upload error:', err);
            setError(err.response?.data?.message || 'Failed to upload image');
            setPreview(currentImage);
        } finally {
            setUploading(false);
        }
    };

    const handleRemove = () => {
        setPreview(null);
        onImageUpload(null);
    };

    return (
        <div className="image-upload">
            <div className="upload-container">
                {preview ? (
                    <div className="image-preview">
                        <img src={preview} alt="Preview" />
                        <button
                            type="button"
                            className="remove-btn"
                            onClick={handleRemove}
                            disabled={uploading}
                        >
                            <FaTrash /> Remove
                        </button>
                    </div>
                ) : (
                    <label className="upload-label">
                        <input
                            type="file"
                            accept="image/jpeg,image/jpg,image/png,image/webp"
                            onChange={handleFileSelect}
                            disabled={uploading}
                            style={{ display: 'none' }}
                        />
                        <div className="upload-placeholder">
                            {uploading ? (
                                <div className="uploading">
                                    <div className="spinner"></div>
                                    <p>Uploading...</p>
                                </div>
                            ) : (
                                <>
                                    <FaImage className="upload-icon" />
                                    <p>Click to upload image</p>
                                    <span>JPEG, PNG, WebP (Max 5MB)</span>
                                </>
                            )}
                        </div>
                    </label>
                )}
            </div>

            {error && (
                <div className="upload-error">
                    {error}
                </div>
            )}
        </div>
    );
};

export default ImageUpload;
