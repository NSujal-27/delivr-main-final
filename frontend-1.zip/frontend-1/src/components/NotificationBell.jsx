import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { FaBell } from 'react-icons/fa';
import { useSocket } from '../context/SocketContext';
import restaurantApi from '../services/restaurantApi';
import './NotificationBell.css';

const NotificationBell = () => {
    const [unreadCount, setUnreadCount] = useState(0);
    const [notifications, setNotifications] = useState([]);
    const [showDropdown, setShowDropdown] = useState(false);
    const [loading, setLoading] = useState(false);
    const dropdownRef = useRef(null);
    const { socket } = useSocket();

    useEffect(() => {
        loadUnreadCount();

        // Listen for real-time notifications
        if (socket) {
            socket.on('new_notification', handleNewNotification);
            socket.on('new_order', handleNewOrder);
        }

        // Close dropdown when clicking outside
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setShowDropdown(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);

        return () => {
            if (socket) {
                socket.off('new_notification', handleNewNotification);
                socket.off('new_order', handleNewOrder);
            }
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [socket]);

    const loadUnreadCount = async () => {
        try {
            const response = await restaurantApi.getUnreadCount();
            setUnreadCount(response.count || 0);
        } catch (error) {
            console.error('Error loading unread count:', error);
        }
    };

    const loadNotifications = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getNotifications({ limit: 10 });
            setNotifications(response.data || []);
        } catch (error) {
            console.error('Error loading notifications:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleNewNotification = (data) => {
        console.log('New notification received:', data);
        setUnreadCount(prev => prev + 1);

        // Play notification sound (optional)
        playNotificationSound();

        // If dropdown is open, reload notifications
        if (showDropdown) {
            loadNotifications();
        }
    };

    const handleNewOrder = (data) => {
        console.log('New order received:', data);
        setUnreadCount(prev => prev + 1);
        playNotificationSound();
    };

    const playNotificationSound = () => {
        // Optional: Play notification sound
        try {
            const audio = new Audio('/notification.mp3');
            audio.volume = 0.5;
            audio.play().catch(err => console.log('Could not play sound:', err));
        } catch (error) {
            console.log('Sound not available');
        }
    };

    const handleBellClick = () => {
        setShowDropdown(!showDropdown);
        if (!showDropdown) {
            loadNotifications();
        }
    };

    const handleMarkAsRead = async (notificationId) => {
        try {
            await restaurantApi.markNotificationAsRead(notificationId);
            setUnreadCount(prev => Math.max(0, prev - 1));
            loadNotifications();
        } catch (error) {
            console.error('Error marking notification as read:', error);
        }
    };

    const handleMarkAllAsRead = async () => {
        try {
            await restaurantApi.markAllNotificationsAsRead();
            setUnreadCount(0);
            loadNotifications();
        } catch (error) {
            console.error('Error marking all as read:', error);
        }
    };

    const formatTime = (date) => {
        const now = new Date();
        const notifDate = new Date(date);
        const diff = Math.floor((now - notifDate) / 1000 / 60);

        if (diff < 1) return 'Just now';
        if (diff < 60) return `${diff}m ago`;
        if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
        return notifDate.toLocaleDateString();
    };

    const getNotificationLink = (notification) => {
        if (notification.type === 'order' && notification.orderId) {
            return '/restaurant/orders';
        }
        if (notification.type === 'support' && notification.ticketId) {
            return '/restaurant/support';
        }
        return '/restaurant/dashboard';
    };

    return (
        <div className="notification-bell" ref={dropdownRef}>
            <button className="bell-button" onClick={handleBellClick}>
                <FaBell />
                {unreadCount > 0 && (
                    <span className="badge">{unreadCount > 99 ? '99+' : unreadCount}</span>
                )}
            </button>

            {showDropdown && (
                <div className="notification-dropdown">
                    <div className="dropdown-header">
                        <h3>Notifications</h3>
                        {unreadCount > 0 && (
                            <button className="mark-all-read" onClick={handleMarkAllAsRead}>
                                Mark all as read
                            </button>
                        )}
                    </div>

                    <div className="notification-list">
                        {loading ? (
                            <div className="loading-notifications">Loading...</div>
                        ) : notifications.length === 0 ? (
                            <div className="no-notifications">No notifications</div>
                        ) : (
                            notifications.map((notification) => (
                                <Link
                                    key={notification._id}
                                    to={getNotificationLink(notification)}
                                    className={`notification-item ${notification.read ? 'read' : 'unread'}`}
                                    onClick={() => {
                                        if (!notification.read) {
                                            handleMarkAsRead(notification._id);
                                        }
                                        setShowDropdown(false);
                                    }}
                                >
                                    <div className="notification-content">
                                        <div className="notification-title">{notification.title}</div>
                                        <div className="notification-message">{notification.message}</div>
                                        <div className="notification-time">{formatTime(notification.createdAt)}</div>
                                    </div>
                                    {!notification.read && <div className="unread-indicator"></div>}
                                </Link>
                            ))
                        )}
                    </div>

                    {notifications.length > 0 && (
                        <div className="dropdown-footer">
                            <Link to="/restaurant/notifications" onClick={() => setShowDropdown(false)}>
                                View all notifications
                            </Link>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default NotificationBell;
