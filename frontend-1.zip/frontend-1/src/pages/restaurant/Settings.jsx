import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaSave } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Settings.css';

const Settings = () => {
    const [settings, setSettings] = useState({
        restaurantName: '',
        address: '',
        city: '',
        state: '',
        pincode: '',
        phone: '',
        email: '',
        openTime: '10:00',
        closeTime: '22:00',
        deliveryRadius: 5,
        gstNumber: '',
        fssaiNumber: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
        contactPersonName: '',
        contactPersonPhone: '',
        managerName: '',
        managerPhone: ''
    });
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const { showToast } = useToast();

    useEffect(() => {
        loadRestaurantData();
    }, []);

    const loadRestaurantData = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getProfile();
            const restaurant = response.data;

            setSettings({
                restaurantName: restaurant.name || '',
                address: restaurant.address || '',
                city: restaurant.city || '',
                state: restaurant.state || '',
                pincode: restaurant.pincode || '',
                phone: restaurant.phone || '',
                email: restaurant.email || '',
                openTime: restaurant.operatingHours?.open || '10:00',
                closeTime: restaurant.operatingHours?.close || '22:00',
                deliveryRadius: restaurant.deliveryRadius || 5,
                gstNumber: restaurant.taxInfo?.gstNumber || '',
                fssaiNumber: restaurant.taxInfo?.fssaiNumber || '',
                bankName: restaurant.bankInfo?.bankName || '',
                accountNumber: restaurant.bankInfo?.accountNumber || '',
                ifscCode: restaurant.bankInfo?.ifscCode || '',
                contactPersonName: restaurant.contactMembers?.contactPersonName || '',
                contactPersonPhone: restaurant.contactMembers?.contactPersonPhone || '',
                managerName: restaurant.contactMembers?.managerName || '',
                managerPhone: restaurant.contactMembers?.managerPhone || ''
            });
        } catch (error) {
            showToast('Failed to load restaurant settings', 'error');
            console.error('Error loading restaurant data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        setSettings({ ...settings, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            setSaving(true);
            await restaurantApi.updateSettings({
                name: settings.restaurantName,
                address: settings.address,
                city: settings.city,
                state: settings.state,
                pincode: settings.pincode,
                phone: settings.phone,
                email: settings.email,
                operatingHours: {
                    open: settings.openTime,
                    close: settings.closeTime
                },
                deliveryRadius: settings.deliveryRadius,
                taxInfo: {
                    gstNumber: settings.gstNumber,
                    fssaiNumber: settings.fssaiNumber
                },
                bankInfo: {
                    bankName: settings.bankName,
                    accountNumber: settings.accountNumber,
                    ifscCode: settings.ifscCode
                },
                contactMembers: {
                    contactPersonName: settings.contactPersonName,
                    contactPersonPhone: settings.contactPersonPhone,
                    managerName: settings.managerName,
                    managerPhone: settings.managerPhone
                }
            });
            showToast('Settings saved successfully!', 'success');
        } catch (error) {
            showToast('Failed to save settings', 'error');
            console.error('Error saving settings:', error);
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="restaurant-settings">
            <Navbar />

            <div className="container">
                <div className="settings-header">
                    <h1>Restaurant Settings</h1>
                    <p>Manage your restaurant information</p>
                </div>

                {loading ? (
                    <div className="loading">Loading restaurant settings...</div>
                ) : (
                    <form onSubmit={handleSubmit} className="settings-form">
                        {/* Basic Information */}
                        <div className="settings-section">
                            <h2>Basic Information</h2>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Restaurant Name</label>
                                    <input
                                        type="text"
                                        name="restaurantName"
                                        value={settings.restaurantName}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Email</label>
                                    <input
                                        type="email"
                                        name="email"
                                        value={settings.email}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group full-width">
                                    <label>Address</label>
                                    <input
                                        type="text"
                                        name="address"
                                        value={settings.address}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>City</label>
                                    <input
                                        type="text"
                                        name="city"
                                        value={settings.city}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>State</label>
                                    <input
                                        type="text"
                                        name="state"
                                        value={settings.state}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Pincode</label>
                                    <input
                                        type="text"
                                        name="pincode"
                                        value={settings.pincode}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Phone</label>
                                    <input
                                        type="tel"
                                        name="phone"
                                        value={settings.phone}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Operating Hours */}
                        <div className="settings-section">
                            <h2>Operating Hours</h2>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Opening Time</label>
                                    <input
                                        type="time"
                                        name="openTime"
                                        value={settings.openTime}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Closing Time</label>
                                    <input
                                        type="time"
                                        name="closeTime"
                                        value={settings.closeTime}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Delivery Radius (km)</label>
                                    <input
                                        type="number"
                                        name="deliveryRadius"
                                        value={settings.deliveryRadius}
                                        onChange={handleChange}
                                        min="1"
                                        max="50"
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Tax Information */}
                        <div className="settings-section">
                            <h2>Tax Information</h2>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>GST Number</label>
                                    <input
                                        type="text"
                                        name="gstNumber"
                                        value={settings.gstNumber}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>FSSAI Number</label>
                                    <input
                                        type="text"
                                        name="fssaiNumber"
                                        value={settings.fssaiNumber}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Bank Information */}
                        <div className="settings-section">
                            <h2>Bank Information</h2>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Bank Name</label>
                                    <input
                                        type="text"
                                        name="bankName"
                                        value={settings.bankName}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Account Number</label>
                                    <input
                                        type="text"
                                        name="accountNumber"
                                        value={settings.accountNumber}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>IFSC Code</label>
                                    <input
                                        type="text"
                                        name="ifscCode"
                                        value={settings.ifscCode}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Contact Members */}
                        <div className="settings-section">
                            <h2>Contact Members</h2>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Owner/Contact Person Name</label>
                                    <input
                                        type="text"
                                        name="contactPersonName"
                                        value={settings.contactPersonName}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Contact Person Phone</label>
                                    <input
                                        type="tel"
                                        name="contactPersonPhone"
                                        value={settings.contactPersonPhone}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Manager Name</label>
                                    <input
                                        type="text"
                                        name="managerName"
                                        value={settings.managerName}
                                        onChange={handleChange}
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Manager Phone</label>
                                    <input
                                        type="tel"
                                        name="managerPhone"
                                        value={settings.managerPhone}
                                        onChange={handleChange}
                                    />
                                </div>
                            </div>
                        </div>

                        <button type="submit" className="btn btn-primary btn-large" disabled={saving}>
                            <FaSave /> {saving ? 'Saving...' : 'Save Settings'}
                        </button>
                    </form>
                )}
            </div>

            <Footer />
        </div>
    );
};

export default Settings;
