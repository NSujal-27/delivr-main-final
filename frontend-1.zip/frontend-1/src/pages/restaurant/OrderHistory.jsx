import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaCheckCircle, FaChartLine, FaCalendar, FaDownload, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './OrderHistory.css';

const OrderHistory = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [dateFilter, setDateFilter] = useState({
        startDate: '',
        endDate: ''
    });
    const { showToast } = useToast();

    const limit = 20;

    useEffect(() => {
        loadOrders();
    }, [page, dateFilter]);

    const loadOrders = async () => {
        try {
            setLoading(true);
            const params = {
                status: 'completed',
                page,
                limit
            };

            if (dateFilter.startDate) params.startDate = dateFilter.startDate;
            if (dateFilter.endDate) params.endDate = dateFilter.endDate;

            const response = await restaurantApi.getOrders(params);
            setOrders(response.data.data || []);
            setTotalPages(response.data.totalPages || 1);
            setTotal(response.data.total || 0);
        } catch (error) {
            showToast('Failed to load order history', 'error');
            console.error('Error loading orders:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDateFilter = () => {
        setPage(1); // Reset to first page
        loadOrders();
    };

    const handleClearFilter = () => {
        setDateFilter({ startDate: '', endDate: '' });
        setPage(1);
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    };

    const formatTime = (date) => {
        return new Date(date).toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const handleExport = () => {
        showToast('Export functionality coming soon!', 'info');
        // TODO: Implement CSV export
    };

    if (loading && page === 1) {
        return (
            <div className="order-history-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading order history...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="order-history-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <div>
                        <h1>Order History</h1>
                        <p>View completed and delivered orders</p>
                    </div>
                    <button className="btn btn-primary" onClick={handleExport}>
                        <FaDownload /> Export
                    </button>
                </div>

                {/* Date Filter */}
                <div className="filter-section">
                    <div className="date-filters">
                        <div className="filter-group">
                            <label><FaCalendar /> Start Date</label>
                            <input
                                type="date"
                                value={dateFilter.startDate}
                                onChange={(e) => setDateFilter({ ...dateFilter, startDate: e.target.value })}
                            />
                        </div>
                        <div className="filter-group">
                            <label><FaCalendar /> End Date</label>
                            <input
                                type="date"
                                value={dateFilter.endDate}
                                onChange={(e) => setDateFilter({ ...dateFilter, endDate: e.target.value })}
                            />
                        </div>
                        <button className="btn btn-secondary" onClick={handleDateFilter}>
                            Apply Filter
                        </button>
                        {(dateFilter.startDate || dateFilter.endDate) && (
                            <button className="btn btn-outline" onClick={handleClearFilter}>
                                Clear
                            </button>
                        )}
                    </div>
                    <div className="total-count">
                        Total Orders: <strong>{total}</strong>
                    </div>
                </div>

                {/* Order History Table */}
                <div className="history-container">
                    <h2><FaCheckCircle /> Completed Orders</h2>

                    {orders.length === 0 ? (
                        <div className="no-data">
                            <p>No completed orders found</p>
                        </div>
                    ) : (
                        <>
                            <div className="history-table">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Customer</th>
                                            <th>Items</th>
                                            <th>Amount</th>
                                            <th>Date & Time</th>
                                            <th>Payment</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {orders.map((order) => (
                                            <tr key={order._id}>
                                                <td><strong>{order.orderId}</strong></td>
                                                <td>
                                                    {order.userId?.name || 'Guest'}
                                                    <br />
                                                    <span className="phone-text">{order.userId?.phone}</span>
                                                </td>
                                                <td>
                                                    {order.items?.length || 0} item(s)
                                                    <br />
                                                    <span className="items-detail">
                                                        {order.items?.slice(0, 2).map(item => item.name).join(', ')}
                                                        {order.items?.length > 2 && '...'}
                                                    </span>
                                                </td>
                                                <td>₹{order.totalAmount}</td>
                                                <td>
                                                    {formatDate(order.createdAt)}
                                                    <br />
                                                    <span className="time-text">{formatTime(order.createdAt)}</span>
                                                </td>
                                                <td>
                                                    <span className="payment-method">{order.paymentMethod}</span>
                                                    <br />
                                                    <span className={`payment-status ${order.paymentStatus}`}>
                                                        {order.paymentStatus}
                                                    </span>
                                                </td>
                                                <td>
                                                    <span className="status-badge delivered">
                                                        <FaCheckCircle /> Delivered
                                                    </span>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="pagination">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.max(1, p - 1))}
                                        disabled={page === 1}
                                    >
                                        <FaChevronLeft /> Previous
                                    </button>
                                    <span className="page-info">
                                        Page {page} of {totalPages}
                                    </span>
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                        disabled={page === totalPages}
                                    >
                                        Next <FaChevronRight />
                                    </button>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default OrderHistory;
