import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaTicketAlt, FaQuestionCircle, FaTimes, FaPaperPlane, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Support.css';

const Support = () => {
    const [ticketForm, setTicketForm] = useState({
        subject: '',
        category: 'general',
        priority: 'medium',
        description: ''
    });
    const [tickets, setTickets] = useState([]);
    const [selectedTicket, setSelectedTicket] = useState(null);
    const [replyMessage, setReplyMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [filter, setFilter] = useState('all');
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const { showToast } = useToast();

    useEffect(() => {
        loadTickets();
    }, [filter, page]);

    const loadTickets = async () => {
        try {
            setLoading(true);
            const params = { page, limit: 10 };
            if (filter !== 'all') {
                params.status = filter;
            }
            const response = await restaurantApi.getTickets(params);
            setTickets(response.data.data || []);
            setTotalPages(response.data.totalPages || 1);
        } catch (error) {
            showToast('Failed to load tickets', 'error');
            console.error('Error loading tickets:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setSubmitting(true);
            await restaurantApi.createTicket(ticketForm);
            showToast('Support ticket created successfully!', 'success');
            setTicketForm({
                subject: '',
                category: 'general',
                priority: 'medium',
                description: ''
            });
            loadTickets();
        } catch (error) {
            showToast('Failed to create ticket', 'error');
            console.error('Error creating ticket:', error);
        } finally {
            setSubmitting(false);
        }
    };

    const handleViewTicket = async (ticketId) => {
        try {
            const response = await restaurantApi.getTicket(ticketId);
            setSelectedTicket(response.data.data);
        } catch (error) {
            showToast('Failed to load ticket details', 'error');
            console.error('Error loading ticket:', error);
        }
    };

    const handleSendReply = async () => {
        if (!replyMessage.trim() || !selectedTicket) return;

        try {
            await restaurantApi.addTicketReply(selectedTicket._id, replyMessage);
            showToast('Reply sent successfully', 'success');
            setReplyMessage('');
            // Reload ticket details
            handleViewTicket(selectedTicket._id);
        } catch (error) {
            showToast('Failed to send reply', 'error');
            console.error('Error sending reply:', error);
        }
    };

    const handleCloseTicket = async (ticketId) => {
        try {
            await restaurantApi.updateTicket(ticketId, { status: 'closed' });
            showToast('Ticket closed successfully', 'success');
            setSelectedTicket(null);
            loadTickets();
        } catch (error) {
            showToast('Failed to close ticket', 'error');
            console.error('Error closing ticket:', error);
        }
    };

    const getStatusBadge = (status) => {
        const badges = {
            'open': 'status-open',
            'in-progress': 'status-progress',
            'waiting-response': 'status-waiting',
            'resolved': 'status-resolved',
            'closed': 'status-closed'
        };
        return badges[status] || '';
    };

    const getPriorityBadge = (priority) => {
        const badges = {
            'urgent': 'priority-urgent',
            'high': 'priority-high',
            'medium': 'priority-medium',
            'low': 'priority-low'
        };
        return badges[priority] || '';
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return (
        <div className="support-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <h1>Support Center</h1>
                    <p>Get help or raise a support ticket</p>
                </div>

                {/* Contact Info */}
                <div className="contact-section">
                    <h2>Contact Platform Support</h2>
                    <div className="contact-grid">
                        <div className="contact-card">
                            <h3>Phone Support</h3>
                            <p>+91 1800-123-4567</p>
                            <span>Mon-Sun, 24/7</span>
                        </div>
                        <div className="contact-card">
                            <h3>Email Support</h3>
                            <p>support@delivr.com</p>
                            <span>Response within 24 hours</span>
                        </div>
                        <div className="contact-card">
                            <h3>Live Chat</h3>
                            <button className="btn btn-primary btn-sm" onClick={() => showToast('Live chat coming soon!', 'info')}>
                                Start Chat
                            </button>
                            <span>Available 9 AM - 9 PM</span>
                        </div>
                    </div>
                </div>

                {/* Create Ticket */}
                <div className="ticket-section">
                    <h2><FaTicketAlt /> Raise a Support Ticket</h2>
                    <form onSubmit={handleSubmit} className="ticket-form">
                        <div className="form-grid">
                            <div className="form-group">
                                <label>Subject *</label>
                                <input
                                    type="text"
                                    value={ticketForm.subject}
                                    onChange={(e) => setTicketForm({ ...ticketForm, subject: e.target.value })}
                                    required
                                    placeholder="Brief description of the issue"
                                    disabled={submitting}
                                />
                            </div>
                            <div className="form-group">
                                <label>Category *</label>
                                <select
                                    value={ticketForm.category}
                                    onChange={(e) => setTicketForm({ ...ticketForm, category: e.target.value })}
                                    disabled={submitting}
                                >
                                    <option value="technical">Technical Issue</option>
                                    <option value="billing">Billing</option>
                                    <option value="orders">Orders</option>
                                    <option value="account">Account</option>
                                    <option value="general">General</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <label>Priority *</label>
                                <select
                                    value={ticketForm.priority}
                                    onChange={(e) => setTicketForm({ ...ticketForm, priority: e.target.value })}
                                    disabled={submitting}
                                >
                                    <option value="low">Low</option>
                                    <option value="medium">Medium</option>
                                    <option value="high">High</option>
                                    <option value="urgent">Urgent</option>
                                </select>
                            </div>
                            <div className="form-group full-width">
                                <label>Description *</label>
                                <textarea
                                    value={ticketForm.description}
                                    onChange={(e) => setTicketForm({ ...ticketForm, description: e.target.value })}
                                    rows="5"
                                    required
                                    placeholder="Describe your issue in detail..."
                                    disabled={submitting}
                                />
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary" disabled={submitting}>
                            {submitting ? 'Submitting...' : 'Submit Ticket'}
                        </button>
                    </form>
                </div>

                {/* My Tickets */}
                <div className="my-tickets-section">
                    <div className="tickets-header">
                        <h2>My Tickets</h2>
                        <div className="filter-buttons">
                            <button
                                className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
                                onClick={() => { setFilter('all'); setPage(1); }}
                            >
                                All
                            </button>
                            <button
                                className={`filter-btn ${filter === 'open' ? 'active' : ''}`}
                                onClick={() => { setFilter('open'); setPage(1); }}
                            >
                                Open
                            </button>
                            <button
                                className={`filter-btn ${filter === 'resolved' ? 'active' : ''}`}
                                onClick={() => { setFilter('resolved'); setPage(1); }}
                            >
                                Resolved
                            </button>
                            <button
                                className={`filter-btn ${filter === 'closed' ? 'active' : ''}`}
                                onClick={() => { setFilter('closed'); setPage(1); }}
                            >
                                Closed
                            </button>
                        </div>
                    </div>

                    {loading ? (
                        <div className="loading">Loading tickets...</div>
                    ) : tickets.length === 0 ? (
                        <div className="no-data">
                            <p>No tickets found</p>
                        </div>
                    ) : (
                        <>
                            <div className="tickets-list">
                                {tickets.map((ticket) => (
                                    <div
                                        key={ticket._id}
                                        className="ticket-card"
                                        onClick={() => handleViewTicket(ticket._id)}
                                    >
                                        <div className="ticket-header">
                                            <h3>{ticket.ticketId}</h3>
                                            <div className="ticket-badges">
                                                <span className={`status-badge ${getStatusBadge(ticket.status)}`}>
                                                    {ticket.status}
                                                </span>
                                                <span className={`priority-badge ${getPriorityBadge(ticket.priority)}`}>
                                                    {ticket.priority}
                                                </span>
                                            </div>
                                        </div>
                                        <h4>{ticket.subject}</h4>
                                        <div className="ticket-meta">
                                            <span>Category: {ticket.category}</span>
                                            <span>Created: {formatDate(ticket.createdAt)}</span>
                                            {ticket.replies?.length > 0 && (
                                                <span>{ticket.replies.length} reply/replies</span>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="pagination">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.max(1, p - 1))}
                                        disabled={page === 1}
                                    >
                                        <FaChevronLeft /> Previous
                                    </button>
                                    <span className="page-info">
                                        Page {page} of {totalPages}
                                    </span>
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                        disabled={page === totalPages}
                                    >
                                        Next <FaChevronRight />
                                    </button>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>

            {/* Ticket Detail Modal */}
            {selectedTicket && (
                <div className="modal-overlay" onClick={() => setSelectedTicket(null)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h2>{selectedTicket.ticketId}</h2>
                            <button className="close-btn" onClick={() => setSelectedTicket(null)}>
                                <FaTimes />
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="ticket-detail-header">
                                <h3>{selectedTicket.subject}</h3>
                                <div className="ticket-badges">
                                    <span className={`status-badge ${getStatusBadge(selectedTicket.status)}`}>
                                        {selectedTicket.status}
                                    </span>
                                    <span className={`priority-badge ${getPriorityBadge(selectedTicket.priority)}`}>
                                        {selectedTicket.priority}
                                    </span>
                                </div>
                            </div>
                            <div className="ticket-info">
                                <span>Category: {selectedTicket.category}</span>
                                <span>Created: {formatDate(selectedTicket.createdAt)}</span>
                            </div>
                            <div className="ticket-description">
                                <h4>Description:</h4>
                                <p>{selectedTicket.description}</p>
                            </div>

                            {/* Replies */}
                            <div className="replies-section">
                                <h4>Conversation:</h4>
                                <div className="replies-list">
                                    {selectedTicket.replies?.map((reply, index) => (
                                        <div key={index} className={`reply-item ${reply.from}`}>
                                            <div className="reply-header">
                                                <strong>{reply.from === 'restaurant' ? 'You' : 'Support Team'}</strong>
                                                <span>{formatDate(reply.timestamp)}</span>
                                            </div>
                                            <p>{reply.message}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Reply Input */}
                            {selectedTicket.status !== 'closed' && (
                                <div className="reply-input-section">
                                    <textarea
                                        value={replyMessage}
                                        onChange={(e) => setReplyMessage(e.target.value)}
                                        placeholder="Type your reply..."
                                        rows="3"
                                    />
                                    <div className="reply-actions">
                                        <button
                                            className="btn btn-primary"
                                            onClick={handleSendReply}
                                            disabled={!replyMessage.trim()}
                                        >
                                            <FaPaperPlane /> Send Reply
                                        </button>
                                        <button
                                            className="btn btn-danger"
                                            onClick={() => handleCloseTicket(selectedTicket._id)}
                                        >
                                            Close Ticket
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            <Footer />
        </div>
    );
};

export default Support;
