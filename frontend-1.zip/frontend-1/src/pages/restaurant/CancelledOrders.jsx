import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaTimesCircle, FaChartPie, FaCalendar, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './CancelledOrders.css';

const CancelledOrders = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [dateFilter, setDateFilter] = useState({
        startDate: '',
        endDate: ''
    });
    const [stats, setStats] = useState({
        total: 0,
        byReason: {},
        totalRefunded: 0
    });
    const { showToast } = useToast();

    const limit = 20;

    useEffect(() => {
        loadOrders();
    }, [page, dateFilter]);

    const loadOrders = async () => {
        try {
            setLoading(true);
            const params = {
                status: 'cancelled',
                page,
                limit
            };

            if (dateFilter.startDate) params.startDate = dateFilter.startDate;
            if (dateFilter.endDate) params.endDate = dateFilter.endDate;

            const response = await restaurantApi.getOrders(params);
            const cancelledOrders = response.data.data || [];

            setOrders(cancelledOrders);
            setTotalPages(response.data.totalPages || 1);
            setTotal(response.data.total || 0);

            // Calculate stats
            calculateStats(cancelledOrders);
        } catch (error) {
            showToast('Failed to load cancelled orders', 'error');
            console.error('Error loading cancelled orders:', error);
        } finally {
            setLoading(false);
        }
    };

    const calculateStats = (orders) => {
        const reasonCount = {};
        let totalRefunded = 0;

        orders.forEach(order => {
            const reason = order.cancellationReason || 'No reason provided';
            reasonCount[reason] = (reasonCount[reason] || 0) + 1;

            if (order.refundAmount > 0) {
                totalRefunded += order.refundAmount;
            }
        });

        setStats({
            total: orders.length,
            byReason: reasonCount,
            totalRefunded
        });
    };

    const handleDateFilter = () => {
        setPage(1);
        loadOrders();
    };

    const handleClearFilter = () => {
        setDateFilter({ startDate: '', endDate: '' });
        setPage(1);
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    };

    const formatTime = (date) => {
        return new Date(date).toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const getRefundStatusBadge = (status) => {
        const badges = {
            none: 'badge-none',
            pending: 'badge-pending',
            processed: 'badge-processed',
            completed: 'badge-success',
            failed: 'badge-error'
        };
        return badges[status] || 'badge-none';
    };

    if (loading && page === 1) {
        return (
            <div className="cancelled-orders-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading cancelled orders...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="cancelled-orders-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <div>
                        <h1>Cancelled Orders</h1>
                        <p>Track and analyze order cancellations</p>
                    </div>
                </div>

                {/* Statistics */}
                <div className="stats-section">
                    <div className="stat-card">
                        <div className="stat-icon"><FaTimesCircle /></div>
                        <div className="stat-content">
                            <div className="stat-value">{total}</div>
                            <div className="stat-label">Total Cancelled</div>
                        </div>
                    </div>
                    <div className="stat-card">
                        <div className="stat-icon"><FaChartPie /></div>
                        <div className="stat-content">
                            <div className="stat-value">₹{stats.totalRefunded.toLocaleString()}</div>
                            <div className="stat-label">Total Refunded</div>
                        </div>
                    </div>
                    <div className="stat-card reasons">
                        <h3><FaChartPie /> Top Cancellation Reasons</h3>
                        <div className="reasons-list">
                            {Object.entries(stats.byReason)
                                .sort((a, b) => b[1] - a[1])
                                .slice(0, 5)
                                .map(([reason, count]) => (
                                    <div key={reason} className="reason-item">
                                        <span className="reason-text">{reason}</span>
                                        <span className="reason-count">{count}</span>
                                    </div>
                                ))}
                        </div>
                    </div>
                </div>

                {/* Date Filter */}
                <div className="filter-section">
                    <div className="date-filters">
                        <div className="filter-group">
                            <label><FaCalendar /> Start Date</label>
                            <input
                                type="date"
                                value={dateFilter.startDate}
                                onChange={(e) => setDateFilter({ ...dateFilter, startDate: e.target.value })}
                            />
                        </div>
                        <div className="filter-group">
                            <label><FaCalendar /> End Date</label>
                            <input
                                type="date"
                                value={dateFilter.endDate}
                                onChange={(e) => setDateFilter({ ...dateFilter, endDate: e.target.value })}
                            />
                        </div>
                        <button className="btn btn-secondary" onClick={handleDateFilter}>
                            Apply Filter
                        </button>
                        {(dateFilter.startDate || dateFilter.endDate) && (
                            <button className="btn btn-outline" onClick={handleClearFilter}>
                                Clear
                            </button>
                        )}
                    </div>
                </div>

                {/* Cancelled Orders Table */}
                <div className="orders-container">
                    <h2><FaTimesCircle /> Cancelled Orders</h2>

                    {orders.length === 0 ? (
                        <div className="no-data">
                            <p>No cancelled orders found</p>
                        </div>
                    ) : (
                        <>
                            <div className="orders-table">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Customer</th>
                                            <th>Amount</th>
                                            <th>Cancelled Date</th>
                                            <th>Cancelled By</th>
                                            <th>Reason</th>
                                            <th>Refund Status</th>
                                            <th>Refund Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {orders.map((order) => (
                                            <tr key={order._id}>
                                                <td><strong>{order.orderId}</strong></td>
                                                <td>
                                                    {order.userId?.name || 'Guest'}
                                                    <br />
                                                    <span className="phone-text">{order.userId?.phone}</span>
                                                </td>
                                                <td>₹{order.totalAmount}</td>
                                                <td>
                                                    {order.cancelledAt ? (
                                                        <>
                                                            {formatDate(order.cancelledAt)}
                                                            <br />
                                                            <span className="time-text">{formatTime(order.cancelledAt)}</span>
                                                        </>
                                                    ) : (
                                                        <>
                                                            {formatDate(order.createdAt)}
                                                            <br />
                                                            <span className="time-text">{formatTime(order.createdAt)}</span>
                                                        </>
                                                    )}
                                                </td>
                                                <td>
                                                    <span className={`cancelled-by ${order.cancelledBy || 'unknown'}`}>
                                                        {order.cancelledBy || 'Unknown'}
                                                    </span>
                                                </td>
                                                <td>{order.cancellationReason || 'No reason provided'}</td>
                                                <td>
                                                    <span className={`refund-status ${getRefundStatusBadge(order.refundStatus || 'none')}`}>
                                                        {order.refundStatus || 'none'}
                                                    </span>
                                                </td>
                                                <td>
                                                    {order.refundAmount > 0 ? `₹${order.refundAmount}` : '-'}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="pagination">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.max(1, p - 1))}
                                        disabled={page === 1}
                                    >
                                        <FaChevronLeft /> Previous
                                    </button>
                                    <span className="page-info">
                                        Page {page} of {totalPages}
                                    </span>
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                        disabled={page === totalPages}
                                    >
                                        Next <FaChevronRight />
                                    </button>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default CancelledOrders;
