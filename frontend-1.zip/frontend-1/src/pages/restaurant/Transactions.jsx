import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaCheckCircle, FaTimesCircle, FaExchangeAlt } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Transactions.css';

const Transactions = () => {
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');
    const { showToast } = useToast();

    useEffect(() => {
        loadTransactions();
    }, []);

    const loadTransactions = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getTransactions();
            setTransactions(response.data.transactions || []);
        } catch (error) {
            showToast('Failed to load transactions', 'error');
            console.error('Error loading transactions:', error);
        } finally {
            setLoading(false);
        }
    };

    const getTypeIcon = (type) => {
        switch (type) {
            case 'payment': return <FaCheckCircle className="icon-payment" />;
            case 'refund': return <FaTimesCircle className="icon-refund" />;
            case 'transfer': return <FaExchangeAlt className="icon-transfer" />;
            default: return null;
        }
    };

    const getTypeBadge = (type) => {
        const badges = {
            payment: 'badge-payment',
            refund: 'badge-refund',
            transfer: 'badge-transfer'
        };
        return badges[type] || '';
    };

    const formatDate = (date) => {
        const d = new Date(date);
        return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    };

    const formatTime = (date) => {
        const d = new Date(date);
        return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    };

    const filteredTransactions = filter === 'all'
        ? transactions
        : transactions.filter(t => t.type === filter);

    if (loading) {
        return (
            <div className="transactions-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading transactions...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="transactions-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <h1>Transaction History</h1>
                    <p>View all order payments, cancellations, and transfers</p>
                </div>

                <div className="transactions-container">
                    <div className="transactions-header">
                        <h2>All Transactions</h2>
                        <div className="filter-buttons">
                            <button
                                className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
                                onClick={() => setFilter('all')}
                            >
                                All
                            </button>
                            <button
                                className={`filter-btn ${filter === 'payment' ? 'active' : ''}`}
                                onClick={() => setFilter('payment')}
                            >
                                Payments
                            </button>
                            <button
                                className={`filter-btn ${filter === 'refund' ? 'active' : ''}`}
                                onClick={() => setFilter('refund')}
                            >
                                Refunds
                            </button>
                            <button
                                className={`filter-btn ${filter === 'transfer' ? 'active' : ''}`}
                                onClick={() => setFilter('transfer')}
                            >
                                Transfers
                            </button>
                        </div>
                    </div>

                    <div className="transactions-list">
                        {filteredTransactions.length === 0 ? (
                            <div className="no-data">No transactions found</div>
                        ) : (
                            filteredTransactions.map((txn) => (
                                <div key={txn._id} className="transaction-card">
                                    <div className="txn-icon">
                                        {getTypeIcon(txn.type)}
                                    </div>
                                    <div className="txn-details">
                                        <div className="txn-primary">
                                            <h3>{txn.transactionId || txn._id}</h3>
                                            <span className={`txn-type-badge ${getTypeBadge(txn.type)}`}>
                                                {txn.type.toUpperCase()}
                                            </span>
                                        </div>
                                        {txn.orderId && (
                                            <p className="txn-order">Order: {txn.orderId}</p>
                                        )}
                                        {txn.description && (
                                            <p className="txn-note">{txn.description}</p>
                                        )}
                                        <p className="txn-datetime">
                                            {formatDate(txn.createdAt)} at {formatTime(txn.createdAt)}
                                        </p>
                                    </div>
                                    <div className="txn-amount">
                                        <span className={`amount ${txn.type === 'refund' ? 'negative' : 'positive'}`}>
                                            {txn.type === 'refund' ? '-' : '+'}₹{txn.amount?.toLocaleString() || 0}
                                        </span>
                                        <span className="txn-status">{txn.status || 'completed'}</span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Transactions;
