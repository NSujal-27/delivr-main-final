import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaSave, FaArrowLeft } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './AddMenuItem.css';

const AddMenuItem = () => {
    const navigate = useNavigate();
    const { showToast } = useToast();
    const [formData, setFormData] = useState({
        name: '',
        category: 'Biryani',
        price: '',
        description: '',
        isVeg: true,
        isAvailable: true,
        image: ''
    });
    const [saving, setSaving] = useState(false);

    const categories = ['Biryani', 'Starters', 'Main Course', 'Breads', 'Desserts', 'Beverages'];

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            setSaving(true);
            await restaurantApi.addMenuItem({
                name: formData.name,
                category: formData.category,
                price: parseFloat(formData.price),
                description: formData.description,
                isVeg: formData.isVeg,
                isAvailable: formData.isAvailable,
                image: formData.image || 'https://via.placeholder.com/300x200?text=Food+Item'
            });
            showToast('Menu item added successfully!', 'success');
            navigate('/restaurant/menu');
        } catch (error) {
            showToast('Failed to add menu item', 'error');
            console.error('Error adding menu item:', error);
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="add-menu-item-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <h1>Add Menu Item</h1>
                    <button onClick={() => navigate('/restaurant/menu')} className="btn btn-secondary">
                        <FaArrowLeft /> Back to Menu
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="add-item-form">
                    <div className="form-section">
                        <h2>Basic Information</h2>
                        <div className="form-grid">
                            <div className="form-group full-width">
                                <label>Item Name *</label>
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                    required
                                    placeholder="e.g., Chicken Biryani"
                                />
                            </div>

                            <div className="form-group">
                                <label>Category *</label>
                                <select
                                    name="category"
                                    value={formData.category}
                                    onChange={handleChange}
                                    required
                                >
                                    {categories.map((cat) => (
                                        <option key={cat} value={cat}>{cat}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="form-group">
                                <label>Price (₹) *</label>
                                <input
                                    type="number"
                                    name="price"
                                    value={formData.price}
                                    onChange={handleChange}
                                    required
                                    min="0"
                                    step="0.01"
                                    placeholder="280"
                                />
                            </div>

                            <div className="form-group full-width">
                                <label>Description</label>
                                <textarea
                                    name="description"
                                    value={formData.description}
                                    onChange={handleChange}
                                    rows="4"
                                    placeholder="Describe the dish..."
                                />
                            </div>
                        </div>
                    </div>

                    <div className="form-section">
                        <h2>Additional Details</h2>
                        <div className="checkbox-group">
                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    name="isVeg"
                                    checked={formData.isVeg}
                                    onChange={handleChange}
                                />
                                <span>Vegetarian</span>
                            </label>

                            <label className="checkbox-label">
                                <input
                                    type="checkbox"
                                    name="isAvailable"
                                    checked={formData.isAvailable}
                                    onChange={handleChange}
                                />
                                <span>Available for orders</span>
                            </label>
                        </div>
                    </div>

                    <div className="form-section">
                        <h2>Image URL (Optional)</h2>
                        <div className="form-group">
                            <label>Image URL</label>
                            <input
                                type="url"
                                name="image"
                                value={formData.image}
                                onChange={handleChange}
                                placeholder="https://example.com/image.jpg"
                            />
                            <p className="help-text">Leave blank to use default placeholder image</p>
                        </div>
                    </div>

                    <div className="form-section">
                        <button type="button" onClick={() => navigate('/restaurant/menu')} className="btn btn-secondary">
                            Cancel
                        </button>
                        <button type="submit" className="btn btn-primary" disabled={saving}>
                            <FaSave /> {saving ? 'Adding...' : 'Add Menu Item'}
                        </button>
                    </div>
                </form>
            </div>

            <Footer />
        </div>
    );
};

export default AddMenuItem;
