import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaSave, FaClock } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './PrepTime.css';

const PrepTime = () => {
    const [defaultPrepTime, setDefaultPrepTime] = useState(30);
    const [peakHourAdjustment, setPeakHourAdjustment] = useState(10);
    const [categoryTimes, setCategoryTimes] = useState([]);
    const [peakHours, setPeakHours] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const { showToast } = useToast();

    useEffect(() => {
        loadPrepTimeData();
    }, []);

    const loadPrepTimeData = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getPrepTime();
            const prepTime = response.data;

            setDefaultPrepTime(prepTime.default || 30);
            setPeakHourAdjustment(prepTime.peakHourAdjustment || 10);
            setCategoryTimes(prepTime.categoryTimes || [
                { category: 'Biryani', time: 35, enabled: true },
                { category: 'Starters', time: 20, enabled: true },
                { category: 'Main Course', time: 30, enabled: true },
                { category: 'Breads', time: 15, enabled: true },
                { category: 'Desserts', time: 10, enabled: true },
                { category: 'Beverages', time: 5, enabled: true }
            ]);
            setPeakHours(prepTime.peakHours || [
                { day: 'Monday-Friday', startTime: '12:00', endTime: '14:00', enabled: true },
                { day: 'Monday-Friday', startTime: '19:00', endTime: '21:00', enabled: true },
                { day: 'Saturday-Sunday', startTime: '12:00', endTime: '15:00', enabled: true },
                { day: 'Saturday-Sunday', startTime: '19:00', endTime: '22:00', enabled: true }
            ]);
        } catch (error) {
            showToast('Failed to load prep time settings', 'error');
            console.error('Error loading prep time data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCategoryTimeChange = (index, newTime) => {
        const updated = [...categoryTimes];
        updated[index].time = parseInt(newTime);
        setCategoryTimes(updated);
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            await restaurantApi.updatePrepTime({
                default: defaultPrepTime,
                peakHourAdjustment,
                categoryTimes,
                peakHours
            });
            showToast('Prep time settings saved successfully!', 'success');
        } catch (error) {
            showToast('Failed to save prep time settings', 'error');
            console.error('Error saving prep time:', error);
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="prep-time-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading prep time settings...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="prep-time-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <h1>Preparation Time Management</h1>
                    <p>Configure default and category-specific preparation times</p>
                </div>

                {/* Default Prep Time */}
                <div className="settings-card">
                    <h2><FaClock /> Default Preparation Time</h2>
                    <div className="prep-time-control">
                        <label>Default time for all items:</label>
                        <div className="time-input-group">
                            <input
                                type="number"
                                value={defaultPrepTime}
                                onChange={(e) => setDefaultPrepTime(parseInt(e.target.value))}
                                min="5"
                                max="120"
                            />
                            <span>minutes</span>
                        </div>
                        <p className="help-text">
                            This time will be used for items without specific category times
                        </p>
                    </div>
                </div>

                {/* Peak Hour Adjustments */}
                <div className="settings-card">
                    <h2>Peak Hour Adjustments</h2>
                    <div className="prep-time-control">
                        <label>Additional time during peak hours:</label>
                        <div className="time-input-group">
                            <input
                                type="number"
                                value={peakHourAdjustment}
                                onChange={(e) => setPeakHourAdjustment(parseInt(e.target.value))}
                                min="0"
                                max="60"
                            />
                            <span>minutes</span>
                        </div>
                        <p className="help-text">
                            This will be added to prep times during peak hours
                        </p>
                    </div>

                    <div className="peak-hours-list">
                        <h3>Peak Hours Schedule</h3>
                        {peakHours.map((peak, index) => (
                            <div key={index} className="peak-hour-item">
                                <div className="peak-day">{peak.day}</div>
                                <div className="peak-time">
                                    {peak.startTime} - {peak.endTime}
                                </div>
                                <div className="peak-status">
                                    <span className={peak.enabled ? 'status-active' : 'status-inactive'}>
                                        {peak.enabled ? 'Active' : 'Inactive'}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Category Specific Times */}
                <div className="settings-card">
                    <h2>Category-Specific Preparation Times</h2>
                    <div className="category-times-grid">
                        {categoryTimes.map((cat, index) => (
                            <div key={index} className="category-time-card">
                                <div className="category-header">
                                    <h3>{cat.category}</h3>
                                    <span className={cat.enabled ? 'badge-active' : 'badge-inactive'}>
                                        {cat.enabled ? 'Enabled' : 'Disabled'}
                                    </span>
                                </div>
                                <div className="category-time-input">
                                    <input
                                        type="number"
                                        value={cat.time}
                                        onChange={(e) => handleCategoryTimeChange(index, e.target.value)}
                                        min="5"
                                        max="120"
                                        disabled={!cat.enabled}
                                    />
                                    <span>minutes</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Summary */}
                <div className="settings-card summary-card">
                    <h2>Summary</h2>
                    <div className="summary-grid">
                        <div className="summary-item">
                            <span className="summary-label">Default Prep Time:</span>
                            <span className="summary-value">{defaultPrepTime} min</span>
                        </div>
                        <div className="summary-item">
                            <span className="summary-label">Peak Hour Addition:</span>
                            <span className="summary-value">+{peakHourAdjustment} min</span>
                        </div>
                        <div className="summary-item">
                            <span className="summary-label">During Peak Hours:</span>
                            <span className="summary-value">{defaultPrepTime + peakHourAdjustment} min</span>
                        </div>
                        <div className="summary-item">
                            <span className="summary-label">Active Categories:</span>
                            <span className="summary-value">{categoryTimes.filter(c => c.enabled).length}</span>
                        </div>
                    </div>
                </div>

                <button onClick={handleSave} className="btn btn-primary btn-large" disabled={saving}>
                    <FaSave /> {saving ? 'Saving...' : 'Save Preparation Times'}
                </button>
            </div>

            <Footer />
        </div>
    );
};

export default PrepTime;
