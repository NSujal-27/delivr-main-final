import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaPlus, FaEdit, FaTrash, FaSearch, FaToggleOn, FaToggleOff } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './MenuManagement.css';

const MenuManagement = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [menuItems, setMenuItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const { showToast } = useToast();

    useEffect(() => {
        loadMenuItems();
    }, []);

    const loadMenuItems = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getMenu();
            setMenuItems(response.data);
        } catch (error) {
            showToast('Failed to load menu items', 'error');
            console.error('Error loading menu:', error);
        } finally {
            setLoading(false);
        }
    };

    const toggleAvailability = async (id) => {
        try {
            await restaurantApi.toggleAvailability(id);
            setMenuItems(menuItems.map(item =>
                item._id === id ? { ...item, isAvailable: !item.isAvailable } : item
            ));
            showToast('Availability updated', 'success');
        } catch (error) {
            showToast('Failed to update availability', 'error');
            console.error('Error toggling availability:', error);
        }
    };

    const deleteItem = async (id) => {
        if (window.confirm('Are you sure you want to delete this item?')) {
            try {
                await restaurantApi.deleteMenuItem(id);
                setMenuItems(menuItems.filter(item => item._id !== id));
                showToast('Menu item deleted', 'success');
            } catch (error) {
                showToast('Failed to delete item', 'error');
                console.error('Error deleting item:', error);
            }
        }
    };

    const filteredItems = menuItems.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const categories = [...new Set(menuItems.map(item => item.category))];

    if (loading) {
        return (
            <div className="menu-management-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading menu items...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="menu-management-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <div>
                        <h1>Menu Management</h1>
                        <p>Manage your restaurant menu items</p>
                    </div>
                    <Link to="/restaurant/menu/add" className="btn btn-primary">
                        <FaPlus /> Add New Item
                    </Link>
                </div>

                {/* Search Bar */}
                <div className="search-section">
                    <div className="search-box">
                        <FaSearch />
                        <input
                            type="text"
                            placeholder="Search by name or category..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <div className="stats">
                        <span>Total Items: <strong>{menuItems.length}</strong></span>
                        <span>Categories: <strong>{categories.length}</strong></span>
                        <span>Available: <strong>{menuItems.filter(i => i.isAvailable).length}</strong></span>
                    </div>
                </div>

                {/* Menu Items */}
                <div className="menu-container">
                    {categories.length === 0 ? (
                        <div className="no-data">
                            <p>No menu items found. Add your first menu item to get started!</p>
                            <Link to="/restaurant/menu/add" className="btn btn-primary">
                                <FaPlus /> Add First Item
                            </Link>
                        </div>
                    ) : (
                        categories.map((category) => {
                            const categoryItems = filteredItems.filter(item => item.category === category);
                            if (categoryItems.length === 0) return null;

                            return (
                                <div key={category} className="category-section">
                                    <h2>{category}</h2>
                                    <div className="menu-items-grid">
                                        {categoryItems.map((item) => (
                                            <div key={item._id} className={`menu-item-card ${!item.isAvailable ? 'unavailable' : ''}`}>
                                                <div className="item-header">
                                                    <h3>{item.name}</h3>
                                                    <button
                                                        onClick={() => toggleAvailability(item._id)}
                                                        className={`toggle-btn ${item.isAvailable ? 'active' : ''}`}
                                                        title={item.isAvailable ? 'Click to mark unavailable' : 'Click to mark available'}
                                                    >
                                                        {item.isAvailable ? <FaToggleOn /> : <FaToggleOff />}
                                                    </button>
                                                </div>
                                                <p className="item-description">{item.description}</p>
                                                <div className="item-info">
                                                    <span className="item-type">{item.isVeg ? '🟢 Veg' : '🔴 Non-Veg'}</span>
                                                    <span className="item-rating">⭐ {item.rating || 4.0}</span>
                                                </div>
                                                <div className="item-price">₹{item.price}</div>
                                                <div className="item-status">
                                                    {item.isAvailable ? (
                                                        <span className="status-available">Available</span>
                                                    ) : (
                                                        <span className="status-unavailable">Unavailable</span>
                                                    )}
                                                </div>
                                                <div className="item-actions">
                                                    <Link to={`/restaurant/menu/edit/${item._id}`} className="btn-edit">
                                                        <FaEdit /> Edit
                                                    </Link>
                                                    <button
                                                        className="btn-delete"
                                                        onClick={() => deleteItem(item._id)}
                                                    >
                                                        <FaTrash /> Delete
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default MenuManagement;
