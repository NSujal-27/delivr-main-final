import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaClock, FaCheck, FaTimes } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Orders.css';

const Orders = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const { showToast } = useToast();

    useEffect(() => {
        loadOrders();
        // Refresh orders every 30 seconds
        const interval = setInterval(loadOrders, 30000);
        return () => clearInterval(interval);
    }, []);

    const loadOrders = async () => {
        try {
            const response = await restaurantApi.getOrders('active');
            setOrders(response.data);
        } catch (error) {
            showToast('Failed to load orders', 'error');
            console.error('Error loading orders:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAccept = async (orderId) => {
        try {
            await restaurantApi.updateOrderStatus(orderId, 'confirmed');
            showToast('Order accepted', 'success');
            loadOrders();
        } catch (error) {
            showToast('Failed to accept order', 'error');
            console.error('Error accepting order:', error);
        }
    };

    const handleReject = async (orderId) => {
        if (window.confirm('Are you sure you want to reject this order?')) {
            try {
                await restaurantApi.updateOrderStatus(orderId, 'cancelled');
                showToast('Order rejected', 'success');
                loadOrders();
            } catch (error) {
                showToast('Failed to reject order', 'error');
                console.error('Error rejecting order:', error);
            }
        }
    };

    const handleMarkReady = async (orderId) => {
        try {
            await restaurantApi.updateOrderStatus(orderId, 'ready');
            showToast('Order marked as ready', 'success');
            loadOrders();
        } catch (error) {
            showToast('Failed to update order status', 'error');
            console.error('Error updating order:', error);
        }
    };

    const formatTime = (date) => {
        const orderDate = new Date(date);
        const now = new Date();
        const diff = Math.floor((now - orderDate) / 1000 / 60);

        if (diff < 1) return 'Just now';
        if (diff < 60) return `${diff}m ago`;
        return `${Math.floor(diff / 60)}h ago`;
    };

    const newOrders = orders.filter(o => o.status === 'pending');
    const preparingOrders = orders.filter(o => ['confirmed', 'preparing'].includes(o.status));

    if (loading) {
        return (
            <div className="restaurant-orders">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading orders...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="restaurant-orders">
            <Navbar />

            <div className="container">
                <div className="orders-header">
                    <h1>Order Management</h1>
                    <p>Manage incoming and active orders</p>
                </div>

                {/* New Orders Section */}
                <div className="orders-section">
                    <h2 className="section-title">
                        New Orders <span className="count-badge">{newOrders.length}</span>
                    </h2>

                    {newOrders.length === 0 ? (
                        <div className="empty-state">
                            <p>No new orders at the moment</p>
                        </div>
                    ) : (
                        <div className="orders-list">
                            {newOrders.map((order) => (
                                <div key={order._id} className="order-card new-order">
                                    <div className="order-header">
                                        <div>
                                            <h3>{order.orderId}</h3>
                                            <p className="customer-name">{order.userId?.name || 'Guest'}</p>
                                            <span className="order-time">{formatTime(order.createdAt)}</span>
                                        </div>
                                        <div className="order-total">
                                            <span className="total-label">Total</span>
                                            <span className="total-amount">₹{order.totalAmount}</span>
                                        </div>
                                    </div>

                                    <div className="order-items">
                                        {order.items?.map((item, index) => (
                                            <div key={index} className="order-item">
                                                <span className="item-name">{item.name} x{item.quantity}</span>
                                                <span className="item-price">₹{item.price * item.quantity}</span>
                                            </div>
                                        ))}
                                    </div>

                                    {order.deliveryAddress && (
                                        <div className="delivery-address">
                                            <strong>Delivery Address:</strong> {order.deliveryAddress.street}, {order.deliveryAddress.city}
                                        </div>
                                    )}

                                    <div className="order-actions">
                                        <button
                                            className="btn btn-success"
                                            onClick={() => handleAccept(order._id)}
                                        >
                                            <FaCheck /> Accept Order
                                        </button>
                                        <button
                                            className="btn btn-danger"
                                            onClick={() => handleReject(order._id)}
                                        >
                                            <FaTimes /> Reject
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Preparing Orders Section */}
                <div className="orders-section">
                    <h2 className="section-title">
                        Preparing <span className="count-badge">{preparingOrders.length}</span>
                    </h2>

                    {preparingOrders.length === 0 ? (
                        <div className="empty-state">
                            <p>No orders being prepared</p>
                        </div>
                    ) : (
                        <div className="orders-list">
                            {preparingOrders.map((order) => (
                                <div key={order._id} className="order-card preparing-order">
                                    <div className="order-header">
                                        <div>
                                            <h3>{order.orderId}</h3>
                                            <p className="customer-name">{order.userId?.name || 'Guest'}</p>
                                            <span className="order-time">{formatTime(order.createdAt)}</span>
                                        </div>
                                        <div className="order-total">
                                            <span className="total-label">Total</span>
                                            <span className="total-amount">₹{order.totalAmount}</span>
                                        </div>
                                    </div>

                                    <div className="order-items">
                                        {order.items?.map((item, index) => (
                                            <div key={index} className="order-item">
                                                <span className="item-name">{item.name} x{item.quantity}</span>
                                                <span className="item-price">₹{item.price * item.quantity}</span>
                                            </div>
                                        ))}
                                    </div>

                                    <div className="prep-time-display">
                                        <FaClock /> Status: {order.status}
                                    </div>

                                    <button
                                        className="btn btn-primary btn-block"
                                        onClick={() => handleMarkReady(order._id)}
                                    >
                                        Mark as Ready
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Orders;
