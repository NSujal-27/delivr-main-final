import { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaRupeeSign, FaCalendar } from 'react-icons/fa';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Earnings.css';

const Earnings = () => {
    const [earningsData, setEarningsData] = useState({
        daily: 0,
        weekly: 0,
        monthly: 0,
        commission: 0,
        netEarnings: 0
    });
    const [dailyData, setDailyData] = useState([]);
    const [loading, setLoading] = useState(true);
    const { showToast } = useToast();

    useEffect(() => {
        loadEarnings();
    }, []);

    const loadEarnings = async () => {
        try {
            setLoading(true);
            const response = await restaurantApi.getEarnings();
            const data = response.data;

            setEarningsData({
                daily: data.dailyEarnings || 0,
                weekly: data.weeklyEarnings || 0,
                monthly: data.monthlyEarnings || 0,
                commission: data.commission || 0,
                netEarnings: data.netEarnings || 0
            });

            setDailyData(data.dailyBreakdown || []);
        } catch (error) {
            showToast('Failed to load earnings data', 'error');
            console.error('Error loading earnings:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="earnings-page">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading earnings data...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="earnings-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <h1>Earnings & Payments</h1>
                    <p>Track your revenue and commission charges</p>
                </div>

                {/* Earnings Summary */}
                <div className="earnings-summary">
                    <div className="earning-card primary">
                        <div className="earning-icon"><FaRupeeSign /></div>
                        <div className="earning-content">
                            <h3>Today's Earnings</h3>
                            <div className="earning-value">₹{earningsData.daily.toLocaleString()}</div>
                        </div>
                    </div>
                    <div className="earning-card">
                        <div className="earning-icon"><FaCalendar /></div>
                        <div className="earning-content">
                            <h3>This Week</h3>
                            <div className="earning-value">₹{earningsData.weekly.toLocaleString()}</div>
                        </div>
                    </div>
                    <div className="earning-card">
                        <div className="earning-icon"><FaCalendar /></div>
                        <div className="earning-content">
                            <h3>This Month</h3>
                            <div className="earning-value">₹{earningsData.monthly.toLocaleString()}</div>
                        </div>
                    </div>
                </div>

                {/* Commission Breakdown */}
                <div className="commission-card">
                    <h2>Commission Breakdown (This Month)</h2>
                    <div className="commission-grid">
                        <div className="commission-item">
                            <span className="label">Gross Earnings:</span>
                            <span className="value">₹{earningsData.monthly.toLocaleString()}</span>
                        </div>
                        <div className="commission-item deduction">
                            <span className="label">Platform Commission (10%):</span>
                            <span className="value">- ₹{earningsData.commission.toLocaleString()}</span>
                        </div>
                        <div className="commission-item total">
                            <span className="label">Net Earnings:</span>
                            <span className="value">₹{earningsData.netEarnings.toLocaleString()}</span>
                        </div>
                    </div>
                </div>

                {/* Charts */}
                <div className="charts-section">
                    <div className="chart-card">
                        <h2>Weekly Earnings</h2>
                        {dailyData.length > 0 ? (
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={dailyData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="day" />
                                    <YAxis />
                                    <Tooltip />
                                    <Bar dataKey="earnings" fill="#800020" />
                                </BarChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="no-data">No earnings data available</div>
                        )}
                    </div>
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Earnings;
