import { useState } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaDownload, FaFileAlt, FaFilePdf, FaFileCsv, FaCalendar } from 'react-icons/fa';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Reports.css';

const Reports = () => {
    const [reportType, setReportType] = useState('sales');
    const [format, setFormat] = useState('pdf');
    const [dateRange, setDateRange] = useState({
        startDate: '',
        endDate: ''
    });
    const [generating, setGenerating] = useState(false);
    const { showToast } = useToast();

    const reportTypes = [
        { value: 'sales', label: 'Sales Report', description: 'Revenue, orders, and trends' },
        { value: 'menu', label: 'Menu Performance', description: 'Popular items and inventory' },
        { value: 'customer', label: 'Customer Behavior', description: 'Repeat rate and insights' },
        { value: 'financial', label: 'Financial Summary', description: 'Earnings and commission breakdown' }
    ];

    const handleGenerateReport = async () => {
        if (!dateRange.startDate || !dateRange.endDate) {
            showToast('Please select date range', 'error');
            return;
        }

        try {
            setGenerating(true);

            // In a real implementation, this would call the backend report generation API
            // For now, we'll show a coming soon message
            showToast(`${reportType.toUpperCase()} report generation in ${format.toUpperCase()} coming soon!`, 'info');

            // TODO: Implement actual report generation
            // const response = await restaurantApi.generateReport({
            //     type: reportType,
            //     format,
            //     startDate: dateRange.startDate,
            //     endDate: dateRange.endDate
            // });
            // Download the generated report

        } catch (error) {
            showToast('Failed to generate report', 'error');
            console.error('Error generating report:', error);
        } finally {
            setGenerating(false);
        }
    };

    const handleQuickReport = (days) => {
        const end = new Date();
        const start = new Date();
        start.setDate(start.getDate() - days);

        setDateRange({
            startDate: start.toISOString().split('T')[0],
            endDate: end.toISOString().split('T')[0]
        });
    };

    return (
        <div className="reports-page">
            <Navbar />

            <div className="container">
                <div className="page-header">
                    <div>
                        <h1>Reports & Analytics</h1>
                        <p>Generate detailed reports for your restaurant</p>
                    </div>
                </div>

                {/* Report Configuration */}
                <div className="report-config">
                    <h2><FaFileAlt /> Configure Report</h2>

                    {/* Report Type Selection */}
                    <div className="section">
                        <label className="section-label">Report Type</label>
                        <div className="report-types-grid">
                            {reportTypes.map((type) => (
                                <div
                                    key={type.value}
                                    className={`report-type-card ${reportType === type.value ? 'selected' : ''}`}
                                    onClick={() => setReportType(type.value)}
                                >
                                    <h3>{type.label}</h3>
                                    <p>{type.description}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Date Range */}
                    <div className="section">
                        <label className="section-label"><FaCalendar /> Date Range</label>
                        <div className="date-range-controls">
                            <div className="quick-ranges">
                                <button className="btn btn-outline btn-sm" onClick={() => handleQuickReport(7)}>
                                    Last 7 Days
                                </button>
                                <button className="btn btn-outline btn-sm" onClick={() => handleQuickReport(30)}>
                                    Last 30 Days
                                </button>
                                <button className="btn btn-outline btn-sm" onClick={() => handleQuickReport(90)}>
                                    Last 90 Days
                                </button>
                            </div>
                            <div className="date-inputs">
                                <div className="date-input-group">
                                    <label>Start Date</label>
                                    <input
                                        type="date"
                                        value={dateRange.startDate}
                                        onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
                                    />
                                </div>
                                <div className="date-input-group">
                                    <label>End Date</label>
                                    <input
                                        type="date"
                                        value={dateRange.endDate}
                                        onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Format Selection */}
                    <div className="section">
                        <label className="section-label">Export Format</label>
                        <div className="format-options">
                            <div
                                className={`format-option ${format === 'pdf' ? 'selected' : ''}`}
                                onClick={() => setFormat('pdf')}
                            >
                                <FaFilePdf className="format-icon pdf" />
                                <span>PDF</span>
                            </div>
                            <div
                                className={`format-option ${format === 'csv' ? 'selected' : ''}`}
                                onClick={() => setFormat('csv')}
                            >
                                <FaFileCsv className="format-icon csv" />
                                <span>CSV</span>
                            </div>
                        </div>
                    </div>

                    {/* Generate Button */}
                    <div className="generate-section">
                        <button
                            className="btn btn-primary btn-lg"
                            onClick={handleGenerateReport}
                            disabled={generating || !dateRange.startDate || !dateRange.endDate}
                        >
                            <FaDownload /> {generating ? 'Generating...' : 'Generate Report'}
                        </button>
                    </div>
                </div>

                {/* Report Preview Info */}
                <div className="report-info">
                    <h2>Report Preview</h2>
                    <div className="info-card">
                        <h3>{reportTypes.find(t => t.value === reportType)?.label}</h3>
                        <div className="info-grid">
                            <div className="info-item">
                                <span className="info-label">Report Type:</span>
                                <span className="info-value">{reportType.toUpperCase()}</span>
                            </div>
                            <div className="info-item">
                                <span className="info-label">Format:</span>
                                <span className="info-value">{format.toUpperCase()}</span>
                            </div>
                            <div className="info-item">
                                <span className="info-label">Date Range:</span>
                                <span className="info-value">
                                    {dateRange.startDate && dateRange.endDate
                                        ? `${dateRange.startDate} to ${dateRange.endDate}`
                                        : 'Not selected'}
                                </span>
                            </div>
                        </div>
                        <div className="report-includes">
                            <h4>This report includes:</h4>
                            <ul>
                                {reportType === 'sales' && (
                                    <>
                                        <li>Total revenue and order count</li>
                                        <li>Daily sales breakdown</li>
                                        <li>Revenue trends and comparisons</li>
                                        <li>Average order value</li>
                                    </>
                                )}
                                {reportType === 'menu' && (
                                    <>
                                        <li>Most popular items</li>
                                        <li>Item-wise revenue contribution</li>
                                        <li>Category performance</li>
                                        <li>Low-performing items</li>
                                    </>
                                )}
                                {reportType === 'customer' && (
                                    <>
                                        <li>Total and repeat customers</li>
                                        <li>Customer retention rate</li>
                                        <li>Top customers by spend</li>
                                        <li>Ordering patterns</li>
                                    </>
                                )}
                                {reportType === 'financial' && (
                                    <>
                                        <li>Gross revenue</li>
                                        <li>Platform commission breakdown</li>
                                        <li>Net earnings</li>
                                        <li>Payment method distribution</li>
                                    </>
                                )}
                            </ul>
                        </div>
                    </div>
                </div>

                {/* Scheduled Reports (Future Feature) */}
                <div className="scheduled-reports">
                    <h2>Scheduled Reports</h2>
                    <div className="coming-soon-banner">
                        <p>⏰ Schedule automatic report generation - Coming Soon!</p>
                        <span>Get weekly or monthly reports delivered to your email automatically</span>
                    </div>
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Reports;
