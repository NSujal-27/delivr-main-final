import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaShoppingBag, FaRupeeSign, FaClock, FaStar, FaChartLine, FaTrendingUp, FaTrendingDown } from 'react-icons/fa';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useToast } from '../../context/ToastContext';
import restaurantApi from '../../services/restaurantApi';
import './Dashboard.css';

const RestaurantDashboard = () => {
    const [stats, setStats] = useState({
        todayOrders: 0,
        todayRevenue: 0,
        activeOrders: 0,
        totalOrders: 0,
        completedOrders: 0,
        avgRating: 0
    });
    const [recentOrders, setRecentOrders] = useState([]);
    const [salesTrends, setSalesTrends] = useState(null);
    const [popularItems, setPopularItems] = useState([]);
    const [performanceMetrics, setPerformanceMetrics] = useState(null);
    const [loading, setLoading] = useState(true);
    const [period, setPeriod] = useState('week');
    const { showToast } = useToast();

    useEffect(() => {
        loadDashboardData();
        // Refresh dashboard every 30 seconds
        const interval = setInterval(loadDashboardData, 30000);
        return () => clearInterval(interval);
    }, [period]);

    const loadDashboardData = async () => {
        try {
            // Load basic stats
            const dashboardResponse = await restaurantApi.getDashboard();
            setStats(dashboardResponse.data.stats);
            setRecentOrders(dashboardResponse.data.recentOrders);

            // Load analytics data
            const [trendsResponse, itemsResponse, metricsResponse] = await Promise.all([
                restaurantApi.getSalesTrends({ period, compare: 'true' }),
                restaurantApi.getPopularItems({ limit: 5, period }),
                restaurantApi.getPerformanceMetrics()
            ]);

            setSalesTrends(trendsResponse.data);
            setPopularItems(itemsResponse.data);
            setPerformanceMetrics(metricsResponse.data);
        } catch (error) {
            showToast('Failed to load dashboard data', 'error');
            console.error('Error loading dashboard:', error);
        } finally {
            setLoading(false);
        }
    };

    const formatTime = (date) => {
        const orderDate = new Date(date);
        const now = new Date();
        const diff = Math.floor((now - orderDate) / 1000 / 60);

        if (diff < 1) return 'Just now';
        if (diff < 60) return `${diff}m ago`;
        if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
        return orderDate.toLocaleDateString();
    };

    const getStatusClass = (status) => {
        const statusMap = {
            'pending': 'status-pending',
            'confirmed': 'status-confirmed',
            'preparing': 'status-preparing',
            'ready': 'status-ready',
            'picked_up': 'status-delivered',
            'out_for_delivery': 'status-delivered',
            'delivered': 'status-delivered',
            'cancelled': 'status-cancelled'
        };
        return statusMap[status] || 'status-pending';
    };

    const getTrendIcon = (change) => {
        if (!change) return null;
        const value = parseFloat(change);
        if (value > 0) return <FaTrendingUp className="trend-up" />;
        if (value < 0) return <FaTrendingDown className="trend-down" />;
        return null;
    };

    const COLORS = ['#800020', '#A0522D', '#D2691E', '#CD853F', '#DEB887'];

    if (loading) {
        return (
            <div className="restaurant-dashboard">
                <Navbar />
                <div className="container">
                    <div className="loading">Loading dashboard...</div>
                </div>
                <Footer />
            </div>
        );
    }

    return (
        <div className="restaurant-dashboard">
            <Navbar />

            <div className="container">
                <div className="dashboard-header">
                    <div>
                        <h1>Restaurant Dashboard</h1>
                        <p>Welcome back! Here's what's happening today.</p>
                    </div>
                    <div className="period-selector">
                        <select value={period} onChange={(e) => setPeriod(e.target.value)}>
                            <option value="day">Today</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                            <option value="year">This Year</option>
                        </select>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="stats-grid">
                    <div className="stat-card">
                        <div className="stat-icon orders">
                            <FaShoppingBag />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Today's Orders</p>
                            <h2 className="stat-value">{stats.todayOrders}</h2>
                            {salesTrends?.comparison && (
                                <span className="stat-change">
                                    {getTrendIcon(salesTrends.comparison.orderCountChange)}
                                    {Math.abs(salesTrends.comparison.orderCountChange)}% vs last {period}
                                </span>
                            )}
                        </div>
                    </div>

                    <div className="stat-card">
                        <div className="stat-icon revenue">
                            <FaRupeeSign />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Revenue ({period})</p>
                            <h2 className="stat-value">₹{salesTrends?.currentRevenue?.toLocaleString() || 0}</h2>
                            {salesTrends?.comparison && (
                                <span className="stat-change">
                                    {getTrendIcon(salesTrends.comparison.revenueChange)}
                                    {Math.abs(salesTrends.comparison.revenueChange)}% vs previous
                                </span>
                            )}
                        </div>
                    </div>

                    <div className="stat-card">
                        <div className="stat-icon active">
                            <FaClock />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Active Orders</p>
                            <h2 className="stat-value">{stats.activeOrders}</h2>
                            <Link to="/restaurant/orders" className="stat-link">View All →</Link>
                        </div>
                    </div>

                    <div className="stat-card">
                        <div className="stat-icon rating">
                            <FaStar />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Average Rating</p>
                            <h2 className="stat-value">{stats.avgRating || 0} ⭐</h2>
                            {performanceMetrics && (
                                <span className="stat-info">
                                    {performanceMetrics.fulfillmentRate}% fulfillment rate
                                </span>
                            )}
                        </div>
                    </div>
                </div>

                {/* Charts Section */}
                <div className="charts-section">
                    {/* Sales Trend Chart */}
                    <div className="chart-card large">
                        <div className="chart-header">
                            <h2><FaChartLine /> Sales Trends</h2>
                            <span className="chart-subtitle">Revenue over time</span>
                        </div>
                        {salesTrends?.dailyData && salesTrends.dailyData.length > 0 ? (
                            <ResponsiveContainer width="100%" height={300}>
                                <AreaChart data={salesTrends.dailyData}>
                                    <defs>
                                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#800020" stopOpacity={0.8} />
                                            <stop offset="95%" stopColor="#800020" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="date" />
                                    <YAxis />
                                    <Tooltip />
                                    <Area type="monotone" dataKey="revenue" stroke="#800020" fillOpacity={1} fill="url(#colorRevenue)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="no-data">No sales data available for this period</div>
                        )}
                    </div>

                    {/* Popular Items Chart */}
                    <div className="chart-card">
                        <div className="chart-header">
                            <h2>Top Selling Items</h2>
                            <span className="chart-subtitle">Most ordered</span>
                        </div>
                        {popularItems && popularItems.length > 0 ? (
                            <div className="popular-items-list">
                                {popularItems.map((item, index) => (
                                    <div key={index} className="popular-item">
                                        <div className="item-rank">#{index + 1}</div>
                                        <div className="item-info">
                                            <span className="item-name">{item.name}</span>
                                            <span className="item-stats">
                                                {item.quantity} orders • ₹{item.revenue.toLocaleString()}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="no-data">No items data available</div>
                        )}
                    </div>
                </div>

                {/* Recent Orders */}
                <div className="recent-orders-section">
                    <div className="section-header">
                        <h2>Recent Orders</h2>
                        <Link to="/restaurant/orders" className="view-all-btn">View All</Link>
                    </div>

                    <div className="orders-table">
                        {recentOrders.length === 0 ? (
                            <div className="no-data">No recent orders</div>
                        ) : (
                            <table>
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Items</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {recentOrders.map((order) => (
                                        <tr key={order._id}>
                                            <td><strong>{order.orderId}</strong></td>
                                            <td>{order.userId?.name || 'Guest'}</td>
                                            <td>{order.items?.length || 0} items</td>
                                            <td>₹{order.totalAmount}</td>
                                            <td>
                                                <span className={`status-badge ${getStatusClass(order.status)}`}>
                                                    {order.status}
                                                </span>
                                            </td>
                                            <td>{formatTime(order.createdAt)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="quick-actions">
                    <h2>Quick Actions</h2>
                    <div className="actions-grid">
                        <Link to="/restaurant/menu" className="action-card">
                            <h3>Manage Menu</h3>
                            <p>Add, edit, or remove menu items</p>
                        </Link>
                        <Link to="/restaurant/settings" className="action-card">
                            <h3>Restaurant Settings</h3>
                            <p>Update your restaurant information</p>
                        </Link>
                        <Link to="/restaurant/prep-time" className="action-card">
                            <h3>Prep Time Settings</h3>
                            <p>Configure preparation times</p>
                        </Link>
                        <Link to="/restaurant/support" className="action-card">
                            <h3>Support</h3>
                            <p>Get help or raise a ticket</p>
                        </Link>
                    </div>
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default RestaurantDashboard;
