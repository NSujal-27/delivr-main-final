import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import api from '../../utils/api';
import foodApi from '../../services/foodApi';
import { useLocation } from '../../context/LocationContext';
import { useAuth } from '../../context/AuthContext';
import { FaStar, FaClock, FaSearch, FaFilter, FaMapMarkerAlt, FaUtensils, FaHeart, FaRegHeart, FaMotorcycle } from 'react-icons/fa';
import './Restaurants.css';

const Restaurants = () => {
    const [restaurants, setRestaurants] = useState([]);
    const [cuisines, setCuisines] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({
        search: '',
        cuisine: '',
        minRating: '',
        maxPrice: '',
        city: '',
    });

    const { selectedCity, setSelectedCity } = useLocation();
    const { user, updateUser } = useAuth();

    useEffect(() => {
        fetchCuisines();
        fetchRestaurants();
    }, []);

    useEffect(() => {
        fetchRestaurants();
    }, [filters, selectedCity]);

    const fetchCuisines = async () => {
        try {
            setCuisines(['Sushi', 'Burger', 'Pizza', 'Indian', 'Chinese', 'Italian', 'Mexican']);
        } catch (error) {
            console.error('Error fetching cuisines:', error);
        }
    };

    const fetchRestaurants = async () => {
        try {
            setLoading(true);
            const data = await foodApi.getRestaurants();

            let mappedRestaurants = data.map(r => ({
                _id: r.id,
                name: r.title,
                image: r.image,
                cuisines: r.type || [],
                avgRating: isNaN(Number(r.rating)) ? 4.0 : Number(r.rating),
                deliveryTime: '30-40',
                avgPrice: r.minCharge
            }));

            if (filters.search) {
                mappedRestaurants = mappedRestaurants.filter(r =>
                    r.name.toLowerCase().includes(filters.search.toLowerCase())
                );
            }
            if (filters.cuisine) {
                mappedRestaurants = mappedRestaurants.filter(r =>
                    r.cuisines.some(c => c.toLowerCase() === filters.cuisine.toLowerCase())
                );
            }
            if (filters.minRating) {
                mappedRestaurants = mappedRestaurants.filter(r =>
                    r.avgRating >= parseFloat(filters.minRating)
                );
            }

            setRestaurants(mappedRestaurants);
        } catch (error) {
            console.error('Error fetching restaurants:', error);
            setRestaurants([]);
        } finally {
            setLoading(false);
        }
    };

    const isFavorite = (restaurantId) => {
        return user?.favorites?.includes(restaurantId);
    };

    const toggleFavorite = (e, restaurantId) => {
        e.preventDefault();
        e.stopPropagation();

        if (!user) {
            alert("Please login to add favorites");
            return;
        }

        const currentFavorites = user.favorites || [];
        let newFavorites;

        if (currentFavorites.includes(restaurantId)) {
            newFavorites = currentFavorites.filter(id => id !== restaurantId);
        } else {
            newFavorites = [...currentFavorites, restaurantId];
        }

        updateUser({ ...user, favorites: newFavorites });
    };

    return (
        <div className="restaurants-page-new">
            <Navbar />

            <div className="page-header">
                <div className="container">
                    <h1>Browse Restaurants</h1>
                    <p>Find the best food in your area</p>
                </div>
            </div>

            <div className="container main-content">
                {/* Sidebar Filters */}
                <aside className="filters-sidebar">
                    <div className="filter-group search-group">
                        <h3>Search</h3>
                        <div className="sidebar-search">
                            <FaSearch className="search-icon" />
                            <input
                                type="text"
                                placeholder="Restaurant name..."
                                value={filters.search}
                                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="filter-group">
                        <h3>Cuisines</h3>
                        <div className="cuisine-list">
                            <label className={`cuisine-item ${filters.cuisine === '' ? 'active' : ''}`}>
                                <input
                                    type="radio"
                                    name="cuisine"
                                    value=""
                                    checked={filters.cuisine === ''}
                                    onChange={(e) => setFilters({ ...filters, cuisine: e.target.value })}
                                />
                                All Cuisines
                            </label>
                            {cuisines.map(c => (
                                <label key={c} className={`cuisine-item ${filters.cuisine === c ? 'active' : ''}`}>
                                    <input
                                        type="radio"
                                        name="cuisine"
                                        value={c}
                                        checked={filters.cuisine === c}
                                        onChange={(e) => setFilters({ ...filters, cuisine: e.target.value })}
                                    />
                                    {c}
                                </label>
                            ))}
                        </div>
                    </div>

                    <div className="filter-group">
                        <h3>Rating</h3>
                        <div className="rating-list">
                            <label className="rating-item">
                                <input
                                    type="radio"
                                    name="rating"
                                    value=""
                                    checked={filters.minRating === ''}
                                    onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
                                />
                                Any Rating
                            </label>
                            <label className="rating-item">
                                <input
                                    type="radio"
                                    name="rating"
                                    value="4.0"
                                    checked={filters.minRating === '4.0'}
                                    onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
                                />
                                4.0+ Stars
                            </label>
                            <label className="rating-item">
                                <input
                                    type="radio"
                                    name="rating"
                                    value="4.5"
                                    checked={filters.minRating === '4.5'}
                                    onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
                                />
                                4.5+ Stars
                            </label>
                        </div>
                    </div>
                </aside>

                {/* Restaurant List */}
                <main className="restaurants-list-container">
                    <div className="results-header">
                        <h2>{restaurants.length} Restaurants Nearby</h2>
                    </div>

                    {loading ? (
                        <div className="loading">Loading...</div>
                    ) : restaurants.length > 0 ? (
                        <div className="restaurants-list">
                            {restaurants.map((restaurant) => (
                                <Link
                                    to={`/restaurant/${restaurant._id}`}
                                    key={restaurant._id}
                                    className="restaurant-card-horizontal"
                                >
                                    <div className="card-image">
                                        <img src={restaurant.image} alt={restaurant.name} />
                                        <button
                                            className={`favorite-btn-small ${isFavorite(restaurant._id) ? 'active' : ''}`}
                                            onClick={(e) => toggleFavorite(e, restaurant._id)}
                                        >
                                            {isFavorite(restaurant._id) ? <FaHeart /> : <FaRegHeart />}
                                        </button>
                                    </div>
                                    <div className="card-content">
                                        <div className="card-header">
                                            <h3>{restaurant.name}</h3>
                                            <span className="rating-badge">
                                                <FaStar /> {restaurant.avgRating.toFixed(1)}
                                            </span>
                                        </div>
                                        <p className="card-cuisines">
                                            {restaurant.cuisines.join(', ')}
                                        </p>
                                        <div className="card-footer">
                                            <div className="meta-info">
                                                <span className="meta-item">
                                                    <FaClock /> {restaurant.deliveryTime} mins
                                                </span>
                                                <span className="meta-item">
                                                    <FaMotorcycle /> Free Delivery
                                                </span>
                                                <span className="meta-item price">
                                                    {restaurant.avgPrice}
                                                </span>
                                            </div>
                                            <span className="view-btn">View Menu</span>
                                        </div>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    ) : (
                        <div className="no-results">
                            <p>No restaurants found matching your filters.</p>
                            <button onClick={() => setFilters({ search: '', cuisine: '', minRating: '', maxPrice: '', city: '' })}>
                                Clear Filters
                            </button>
                        </div>
                    )}
                </main>
            </div>
            <Footer />
        </div>
    );
};

export default Restaurants;
