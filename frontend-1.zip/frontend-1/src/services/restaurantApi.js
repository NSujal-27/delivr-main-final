import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance with default config
const api = axios.create({
    baseURL: API_URL,
});

// Add auth token to requests
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

const restaurantApi = {
    // Profile & Settings
    getProfile: async () => {
        const response = await api.get('/restaurant/profile');
        return response.data;
    },

    updateSettings: async (settings) => {
        const response = await api.put('/restaurant/settings', settings);
        return response.data;
    },

    // Prep Time
    getPrepTime: async () => {
        const response = await api.get('/restaurant/prep-time');
        return response.data;
    },

    updatePrepTime: async (prepTimeConfig) => {
        const response = await api.put('/restaurant/prep-time', prepTimeConfig);
        return response.data;
    },

    // Dashboard
    getDashboard: async () => {
        const response = await api.get('/restaurant/dashboard');
        return response.data;
    },

    // Orders
    getOrders: async (params = {}) => {
        // Support both old format (status string) and new format (params object)
        if (typeof params === 'string') {
            params = { status: params };
        }
        const response = await api.get('/restaurant/orders', { params });
        return response.data;
    },

    updateOrderStatus: async (orderId, status) => {
        const response = await api.put(`/restaurant/orders/${orderId}/status`, { status });
        return response.data;
    },

    // Menu Management
    getMenu: async () => {
        const response = await api.get('/restaurant/menu');
        return response.data;
    },

    addMenuItem: async (menuItem) => {
        const response = await api.post('/restaurant/menu', menuItem);
        return response.data;
    },

    updateMenuItem: async (itemId, menuItem) => {
        const response = await api.put(`/restaurant/menu/${itemId}`, menuItem);
        return response.data;
    },

    deleteMenuItem: async (itemId) => {
        const response = await api.delete(`/restaurant/menu/${itemId}`);
        return response.data;
    },

    toggleAvailability: async (itemId) => {
        const response = await api.patch(`/restaurant/menu/${itemId}/availability`);
        return response.data;
    },

    // Earnings & Transactions
    getEarnings: async (startDate, endDate) => {
        const params = {};
        if (startDate) params.startDate = startDate;
        if (endDate) params.endDate = endDate;
        const response = await api.get('/restaurant/earnings', { params });
        return response.data;
    },

    getTransactions: async (page = 1, limit = 20) => {
        const response = await api.get(`/restaurant/transactions?page=${page}&limit=${limit}`);
        return response.data;
    },

    // Support Tickets (Phase-2)
    createTicket: async (ticketData) => {
        const response = await api.post('/restaurant/support/tickets', ticketData);
        return response.data;
    },

    getTickets: async (params = {}) => {
        const response = await api.get('/restaurant/support/tickets', { params });
        return response.data;
    },

    getTicket: async (ticketId) => {
        const response = await api.get(`/restaurant/support/tickets/${ticketId}`);
        return response.data;
    },

    updateTicket: async (ticketId, updates) => {
        const response = await api.put(`/restaurant/support/tickets/${ticketId}`, updates);
        return response.data;
    },

    addTicketReply: async (ticketId, message) => {
        const response = await api.post(`/restaurant/support/tickets/${ticketId}/reply`, { message });
        return response.data;
    },

    // Analytics (Phase-2)
    getSalesTrends: async (params = {}) => {
        const response = await api.get('/restaurant/analytics/sales-trends', { params });
        return response.data;
    },

    getPopularItems: async (params = {}) => {
        const response = await api.get('/restaurant/analytics/popular-items', { params });
        return response.data;
    },

    getPeakHours: async (params = {}) => {
        const response = await api.get('/restaurant/analytics/peak-hours', { params });
        return response.data;
    },

    getCustomerInsights: async () => {
        const response = await api.get('/restaurant/analytics/customer-insights');
        return response.data;
    },

    getPerformanceMetrics: async () => {
        const response = await api.get('/restaurant/analytics/performance-metrics');
        return response.data;
    },

    // Notifications (Phase-2)
    getNotifications: async (params = {}) => {
        const response = await api.get('/restaurant/notifications', { params });
        return response.data;
    },

    getUnreadCount: async () => {
        const response = await api.get('/restaurant/notifications/unread-count');
        return response.data;
    },

    markNotificationAsRead: async (notificationId) => {
        const response = await api.put(`/restaurant/notifications/${notificationId}/read`);
        return response.data;
    },

    markAllNotificationsAsRead: async () => {
        const response = await api.put('/restaurant/notifications/mark-all-read');
        return response.data;
    },

    deleteNotification: async (notificationId) => {
        const response = await api.delete(`/restaurant/notifications/${notificationId}`);
        return response.data;
    },

    // Discounts (Phase-2)
    createDiscount: async (discountData) => {
        const response = await api.post('/restaurant/discounts', discountData);
        return response.data;
    },

    getDiscounts: async (params = {}) => {
        const response = await api.get('/restaurant/discounts', { params });
        return response.data;
    },

    getDiscount: async (discountId) => {
        const response = await api.get(`/restaurant/discounts/${discountId}`);
        return response.data;
    },

    updateDiscount: async (discountId, updates) => {
        const response = await api.put(`/restaurant/discounts/${discountId}`, updates);
        return response.data;
    },

    deleteDiscount: async (discountId) => {
        const response = await api.delete(`/restaurant/discounts/${discountId}`);
        return response.data;
    },

    toggleDiscount: async (discountId) => {
        const response = await api.patch(`/restaurant/discounts/${discountId}/toggle`);
        return response.data;
    },

    getDiscountStats: async (discountId) => {
        const response = await api.get(`/restaurant/discounts/${discountId}/stats`);
        return response.data;
    },
};

export default restaurantApi;
