const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');
const supportController = require('../controllers/supportController');

// All routes are protected and require restaurant role
router.use(auth.protect, roleCheck.authorize('restaurant'));

// Ticket routes
router.post('/tickets', supportController.createTicket);
router.get('/tickets', supportController.getTickets);
router.get('/tickets/:id', supportController.getTicket);
router.put('/tickets/:id', supportController.updateTicket);
router.post('/tickets/:id/reply', supportController.addReply);

module.exports = router;
