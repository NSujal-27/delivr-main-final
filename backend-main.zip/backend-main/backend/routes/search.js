const express = require('express');
const { esClient } = require('../config/elasticsearch');

const router = express.Router();

// Elasticsearch Search Handler
const searchHandler = async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) {
            return res.status(400).json({ success: false, message: 'Please provide a search query' });
        }

        // If Elasticsearch is not available, fall back to MongoDB search
        if (!esClient) {
            return require('../controllers/searchController').searchRestaurantsAndFood(req, res);
        }

        const result = await esClient.search({
            index: 'restaurants', // Assuming we index data here
            body: {
                query: {
                    multi_match: {
                        query: q,
                        fields: ['name', 'cuisine', 'menu.name']
                    }
                }
            }
        });

        const hits = result.hits.hits.map(hit => hit._source);

        res.status(200).json({
            success: true,
            count: hits.length,
            data: hits
        });
    } catch (error) {
        console.error('Elasticsearch Error:', error.message);
        // Fallback to original controller if ES fails or index doesn't exist
        require('../controllers/searchController').searchRestaurantsAndFood(req, res);
    }
};

router.get('/', searchHandler);

module.exports = router;
