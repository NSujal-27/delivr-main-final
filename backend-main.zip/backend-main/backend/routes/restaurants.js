const express = require('express');
const {
    getRestaurants,
    getRestaurantById,
    getRestaurantMenu,
    getCuisines,
    getLocations,
} = require('../controllers/restaurantController');

const router = express.Router();

// Routes
const { redisClient } = require('../config/redis');

// Cache middleware
const cache = async (req, res, next) => {
    if (!redisClient) {
        // Skip caching if Redis is not available
        return next();
    }

    try {
        const key = `restaurants:${JSON.stringify(req.query)}`;
        const cachedData = await redisClient.get(key);

        if (cachedData) {
            return res.status(200).json(JSON.parse(cachedData));
        }
        next();
    } catch (error) {
        console.error('Redis Cache Error:', error.message);
        next();
    }
};

router.get('/', cache, async (req, res, next) => {
    // Wrap the original controller to cache the response
    const originalJson = res.json;
    res.json = function (body) {
        if (res.statusCode === 200 && redisClient) {
            try {
                const key = `restaurants:${JSON.stringify(req.query)}`;
                redisClient.setEx(key, 60, JSON.stringify(body)); // Cache for 60s
            } catch (error) {
                console.error('Redis Cache Write Error:', error.message);
            }
        }
        return originalJson.call(this, body);
    };
    getRestaurants(req, res, next);
});
router.get('/cuisines', getCuisines);
router.get('/locations', getLocations);
router.get('/:id', getRestaurantById);
router.get('/:id/menu', getRestaurantMenu);

module.exports = router;
