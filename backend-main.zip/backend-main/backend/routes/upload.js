const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');
const upload = require('../middleware/upload');
const uploadController = require('../controllers/uploadController');

// All routes are protected and require restaurant role
router.use(auth.protect, roleCheck.authorize('restaurant'));

// Upload routes
router.post('/menu-item', upload.single('image'), uploadController.uploadMenuItemImage);
router.post('/restaurant', upload.single('image'), uploadController.uploadRestaurantImage);
router.delete('/:publicId', uploadController.deleteImage);

module.exports = router;
