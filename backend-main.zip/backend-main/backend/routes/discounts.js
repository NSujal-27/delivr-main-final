const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');
const discountController = require('../controllers/discountController');

// All routes are protected and require restaurant role
router.use(auth.protect, roleCheck.authorize('restaurant'));

// Discount routes
router.post('/', discountController.createDiscount);
router.get('/', discountController.getDiscounts);
router.get('/:id', discountController.getDiscount);
router.put('/:id', discountController.updateDiscount);
router.delete('/:id', discountController.deleteDiscount);
router.patch('/:id/toggle', discountController.toggleDiscount);
router.get('/:id/stats', discountController.getDiscountStats);

module.exports = router;
