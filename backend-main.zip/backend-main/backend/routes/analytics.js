const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');
const analyticsController = require('../controllers/analyticsController');

// All routes are protected and require restaurant role
router.use(auth.protect, roleCheck.authorize('restaurant'));

// Analytics routes
router.get('/sales-trends', analyticsController.getSalesTrends);
router.get('/popular-items', analyticsController.getPopularItems);
router.get('/peak-hours', analyticsController.getPeakHours);
router.get('/customer-insights', analyticsController.getCustomerInsights);
router.get('/performance-metrics', analyticsController.getPerformanceMetrics);

module.exports = router;
