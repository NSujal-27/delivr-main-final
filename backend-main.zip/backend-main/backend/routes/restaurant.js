const express = require('express');
const {
    getProfile,
    updateSettings,
    getPrepTime,
    updatePrepTime,
    getDashboard,
    getOrders,
    updateOrderStatus,
    getMenu,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    toggleAvailability,
    getEarnings,
    getTransactions,
} = require('../controllers/restaurantOwnerController');

const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');

const router = express.Router();

// All routes require authentication and restaurant role
router.use(protect);
router.use(authorize('restaurant'));

// Profile & Settings routes
router.get('/profile', getProfile);
router.put('/settings', updateSettings);

// Prep time routes
router.get('/prep-time', getPrepTime);
router.put('/prep-time', updatePrepTime);

// Dashboard route
router.get('/dashboard', getDashboard);

// Order management routes
router.get('/orders', getOrders);
router.put('/orders/:id/status', updateOrderStatus);

// Menu management routes
router.get('/menu', getMenu);
router.post('/menu', addMenuItem);
router.put('/menu/:id', updateMenuItem);
router.delete('/menu/:id', deleteMenuItem);
router.patch('/menu/:id/availability', toggleAvailability);

// Earnings & Transactions routes
router.get('/earnings', getEarnings);
router.get('/transactions', getTransactions);

module.exports = router;
