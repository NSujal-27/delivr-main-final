const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Restaurant = require('../models/Restaurant');

const initializeSocket = (server) => {
    const io = require('socket.io')(server, {
        cors: {
            origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
            credentials: true,
        },
    });

    // Authentication middleware for Socket.IO
    io.use(async (socket, next) => {
        try {
            const token = socket.handshake.auth.token;

            if (!token) {
                return next(new Error('Authentication error: No token provided'));
            }

            // Verify JWT token
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.id);

            if (!user || user.role !== 'restaurant') {
                return next(new Error('Authentication error: Invalid user or role'));
            }

            // Find restaurant for this user
            const restaurant = await Restaurant.findOne({ userId: user._id });

            if (!restaurant) {
                return next(new Error('Authentication error: Restaurant not found'));
            }

            // Attach user and restaurant to socket
            socket.userId = user._id.toString();
            socket.restaurantId = restaurant._id.toString();
            socket.user = user;

            next();
        } catch (error) {
            console.error('Socket authentication error:', error);
            next(new Error('Authentication error'));
        }
    });

    // Connection handler
    io.on('connection', (socket) => {
        console.log(`Restaurant connected: ${socket.restaurantId} (Socket ID: ${socket.id})`);

        // Join restaurant-specific room
        socket.join(`restaurant:${socket.restaurantId}`);

        // Send connection confirmation
        socket.emit('connected', {
            message: 'Connected to real-time updates',
            restaurantId: socket.restaurantId,
        });

        // Handle disconnection
        socket.on('disconnect', () => {
            console.log(`Restaurant disconnected: ${socket.restaurantId} (Socket ID: ${socket.id})`);
        });

        // Optional: Handle custom events
        socket.on('ping', () => {
            socket.emit('pong', { timestamp: Date.now() });
        });
    });

    // Store io instance globally for use in other modules
    global.io = io;

    console.log('Socket.IO initialized successfully');
    return io;
};

// Helper function to emit events to specific restaurant
const emitToRestaurant = (restaurantId, event, data) => {
    if (global.io) {
        global.io.to(`restaurant:${restaurantId}`).emit(event, data);
    }
};

// Helper function to emit events to all connected restaurants
const emitToAll = (event, data) => {
    if (global.io) {
        global.io.emit(event, data);
    }
};

module.exports = {
    initializeSocket,
    emitToRestaurant,
    emitToAll,
};
