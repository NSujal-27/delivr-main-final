const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Restaurant = require('../models/Restaurant');
const MenuItem = require('../models/MenuItem');
const Order = require('../models/Order');

const seedTestData = async () => {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGO_URI);
        console.log('MongoDB Connected for seeding...');

        // Clear existing data
        console.log('Clearing existing test data...');
        await User.deleteMany({ email: { $regex: /@test\.com$/ } });
        await Restaurant.deleteMany({ name: { $regex: /^Test/ } });

        // Create test restaurant owner user
        console.log('Creating test restaurant owner...');
        const hashedPassword = await bcrypt.hash('Test@1234', 10);

        const restaurantOwner = await User.create({
            name: 'Test Restaurant Owner',
            email: 'restaurant@test.com',
            password: hashedPassword,
            phone: '+91 9999999999',
            role: 'restaurant',
            isVerified: true
        });

        console.log('✓ Restaurant owner created:', restaurantOwner.email);

        // Create test restaurant
        console.log('Creating test restaurant...');
        const restaurant = await Restaurant.create({
            userId: restaurantOwner._id,
            name: 'Test Biryani House',
            cuisine: ['Indian', 'Biryani', 'North Indian'],
            address: '123 Test Street, Test Area',
            city: 'Bangalore',
            state: 'Karnataka',
            pincode: '560001',
            phone: '+91 9999999999',
            email: 'restaurant@test.com',
            location: {
                type: 'Point',
                coordinates: [77.5946, 12.9716] // Bangalore coordinates
            },
            operatingHours: {
                open: '10:00',
                close: '23:00'
            },
            rating: 4.5,
            totalReviews: 150,
            deliveryTime: '30-40 mins',
            costForTwo: 400,
            deliveryRadius: 5,
            image: 'https://via.placeholder.com/400x300?text=Test+Biryani+House',
            isPureVeg: false,
            offers: [
                { title: '50% OFF', description: 'Use code TEST50' }
            ],
            prepTime: {
                default: 30,
                peakHourAdjustment: 10,
                categoryTimes: [
                    { category: 'Biryani', time: 35, enabled: true },
                    { category: 'Starters', time: 20, enabled: true },
                    { category: 'Main Course', time: 30, enabled: true },
                    { category: 'Desserts', time: 10, enabled: true }
                ],
                peakHours: [
                    { day: 'Monday-Friday', startTime: '12:00', endTime: '14:00', enabled: true },
                    { day: 'Monday-Friday', startTime: '19:00', endTime: '21:00', enabled: true }
                ]
            },
            bankInfo: {
                bankName: 'Test Bank',
                accountNumber: '1234567890',
                ifscCode: 'TEST0001234'
            },
            taxInfo: {
                gstNumber: '29ABCDE1234F1Z5',
                fssaiNumber: '12345678901234'
            },
            contactMembers: {
                contactPersonName: 'Test Owner',
                contactPersonPhone: '+91 9999999999',
                managerName: 'Test Manager',
                managerPhone: '+91 9999999998'
            }
        });

        console.log('✓ Restaurant created:', restaurant.name);

        // Create test menu items
        console.log('Creating test menu items...');
        const menuItems = [
            {
                restaurantId: restaurant._id,
                name: 'Chicken Biryani',
                category: 'Biryani',
                price: 280,
                description: 'Authentic Hyderabadi chicken biryani',
                image: 'https://via.placeholder.com/300x200?text=Chicken+Biryani',
                isVeg: false,
                isAvailable: true,
                rating: 4.7
            },
            {
                restaurantId: restaurant._id,
                name: 'Veg Biryani',
                category: 'Biryani',
                price: 220,
                description: 'Delicious vegetable biryani',
                image: 'https://via.placeholder.com/300x200?text=Veg+Biryani',
                isVeg: true,
                isAvailable: true,
                rating: 4.5
            },
            {
                restaurantId: restaurant._id,
                name: 'Chicken 65',
                category: 'Starters',
                price: 180,
                description: 'Spicy fried chicken starter',
                image: 'https://via.placeholder.com/300x200?text=Chicken+65',
                isVeg: false,
                isAvailable: true,
                rating: 4.6
            },
            {
                restaurantId: restaurant._id,
                name: 'Paneer Tikka',
                category: 'Starters',
                price: 160,
                description: 'Grilled cottage cheese with spices',
                image: 'https://via.placeholder.com/300x200?text=Paneer+Tikka',
                isVeg: true,
                isAvailable: true,
                rating: 4.4
            },
            {
                restaurantId: restaurant._id,
                name: 'Gulab Jamun',
                category: 'Desserts',
                price: 60,
                description: 'Sweet Indian dessert',
                image: 'https://via.placeholder.com/300x200?text=Gulab+Jamun',
                isVeg: true,
                isAvailable: true,
                rating: 4.8
            }
        ];

        await MenuItem.insertMany(menuItems);
        console.log(`✓ ${menuItems.length} menu items created`);

        // Create test customer user
        console.log('Creating test customer...');
        const customer = await User.create({
            name: 'Test Customer',
            email: 'customer@test.com',
            password: hashedPassword,
            phone: '+91 8888888888',
            role: 'customer',
            isVerified: true,
            addresses: [
                {
                    street: '456 Customer Street',
                    city: 'Bangalore',
                    state: 'Karnataka',
                    pincode: '560002',
                    isDefault: true
                }
            ]
        });

        console.log('✓ Customer created:', customer.email);

        // Create test orders
        console.log('Creating test orders...');
        const orders = [
            {
                userId: customer._id,
                restaurantId: restaurant._id,
                items: [
                    {
                        menuItemId: menuItems[0]._id,
                        name: menuItems[0].name,
                        quantity: 2,
                        price: menuItems[0].price
                    },
                    {
                        menuItemId: menuItems[2]._id,
                        name: menuItems[2].name,
                        quantity: 1,
                        price: menuItems[2].price
                    }
                ],
                totalAmount: 740,
                status: 'pending',
                deliveryAddress: {
                    street: '456 Customer Street',
                    city: 'Bangalore',
                    state: 'Karnataka',
                    pincode: '560002'
                },
                paymentMethod: 'online',
                paymentStatus: 'paid'
            },
            {
                userId: customer._id,
                restaurantId: restaurant._id,
                items: [
                    {
                        menuItemId: menuItems[1]._id,
                        name: menuItems[1].name,
                        quantity: 1,
                        price: menuItems[1].price
                    }
                ],
                totalAmount: 220,
                status: 'confirmed',
                deliveryAddress: {
                    street: '456 Customer Street',
                    city: 'Bangalore',
                    state: 'Karnataka',
                    pincode: '560002'
                },
                paymentMethod: 'cash',
                paymentStatus: 'pending'
            }
        ];

        await Order.insertMany(orders);
        console.log(`✓ ${orders.length} test orders created`);

        console.log('\n========================================');
        console.log('✨ Test data seeded successfully!');
        console.log('========================================\n');
        console.log('Test Credentials:');
        console.log('─────────────────────────────────────');
        console.log('Restaurant Owner:');
        console.log('  Email: restaurant@test.com');
        console.log('  Password: Test@1234');
        console.log('');
        console.log('Customer:');
        console.log('  Email: customer@test.com');
        console.log('  Password: Test@1234');
        console.log('');
        console.log('Restaurant ID:', restaurant._id);
        console.log('========================================\n');

        process.exit(0);
    } catch (error) {
        console.error('Error seeding data:', error);
        process.exit(1);
    }
};

seedTestData();
