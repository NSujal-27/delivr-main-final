const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
    {
        restaurantId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Restaurant',
            required: true,
            index: true,
        },
        type: {
            type: String,
            enum: ['order', 'system', 'support'],
            default: 'order',
        },
        title: {
            type: String,
            required: true,
        },
        message: {
            type: String,
            required: true,
        },
        orderId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Order',
        },
        ticketId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Ticket',
        },
        read: {
            type: Boolean,
            default: false,
            index: true,
        },
        data: {
            type: mongoose.Schema.Types.Mixed,
        },
    },
    {
        timestamps: true,
    }
);

// Compound index for efficient queries
notificationSchema.index({ restaurantId: 1, read: 1 });
notificationSchema.index({ restaurantId: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
