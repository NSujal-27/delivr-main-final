const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema(
    {
        restaurantId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Restaurant',
            required: true,
        },
        ticketId: {
            type: String,
            unique: true,
        },
        subject: {
            type: String,
            required: true,
            trim: true,
        },
        description: {
            type: String,
            required: true,
        },
        category: {
            type: String,
            enum: ['technical', 'billing', 'orders', 'account', 'general'],
            default: 'general',
        },
        priority: {
            type: String,
            enum: ['low', 'medium', 'high', 'urgent'],
            default: 'medium',
        },
        status: {
            type: String,
            enum: ['open', 'in-progress', 'waiting-response', 'resolved', 'closed'],
            default: 'open',
        },
        attachments: [
            {
                url: String,
                filename: String,
                uploadedAt: {
                    type: Date,
                    default: Date.now,
                },
            },
        ],
        replies: [
            {
                from: {
                    type: String,
                    enum: ['restaurant', 'support'],
                    required: true,
                },
                message: {
                    type: String,
                    required: true,
                },
                timestamp: {
                    type: Date,
                    default: Date.now,
                },
            },
        ],
        resolvedAt: {
            type: Date,
        },
        closedAt: {
            type: Date,
        },
    },
    {
        timestamps: true,
    }
);

// Generate ticket ID before saving
ticketSchema.pre('save', function (next) {
    if (!this.ticketId) {
        this.ticketId = `TKT${Date.now()}${Math.floor(Math.random() * 1000)}`;
    }
    next();
});

// Create indexes
ticketSchema.index({ restaurantId: 1 });
ticketSchema.index({ status: 1 });
ticketSchema.index({ category: 1 });
ticketSchema.index({ priority: 1 });
ticketSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Ticket', ticketSchema);
