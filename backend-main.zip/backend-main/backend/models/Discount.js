const mongoose = require('mongoose');

const discountSchema = new mongoose.Schema(
    {
        restaurantId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Restaurant',
            required: true,
            index: true,
        },
        code: {
            type: String,
            required: true,
            uppercase: true,
            trim: true,
        },
        description: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            enum: ['percentage', 'fixed'],
            required: true,
        },
        value: {
            type: Number,
            required: true,
            min: 0,
        },
        minOrderValue: {
            type: Number,
            default: 0,
            min: 0,
        },
        maxDiscount: {
            type: Number,
            default: null,
        },
        validFrom: {
            type: Date,
            required: true,
        },
        validUntil: {
            type: Date,
            required: true,
        },
        usageLimit: {
            type: Number,
            default: null, // null = unlimited
        },
        usedCount: {
            type: Number,
            default: 0,
        },
        applicableItems: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'MenuItem',
        }],
        applicableCategories: [{
            type: String,
        }],
        isActive: {
            type: Boolean,
            default: true,
        },
        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
    },
    {
        timestamps: true,
    }
);

// Compound index for unique codes per restaurant
discountSchema.index({ restaurantId: 1, code: 1 }, { unique: true });

// Index for active discounts
discountSchema.index({ isActive: 1, validFrom: 1, validUntil: 1 });

// Virtual to check if discount is currently valid
discountSchema.virtual('isCurrentlyValid').get(function () {
    const now = new Date();
    return (
        this.isActive &&
        now >= this.validFrom &&
        now <= this.validUntil &&
        (this.usageLimit === null || this.usedCount < this.usageLimit)
    );
});

// Method to check if discount can be applied to an order
discountSchema.methods.canApplyToOrder = function (orderValue, items = []) {
    // Check if valid
    if (!this.isCurrentlyValid) return false;

    // Check minimum order value
    if (orderValue < this.minOrderValue) return false;

    // Check item restrictions
    if (this.applicableItems.length > 0) {
        const hasApplicableItem = items.some(item =>
            this.applicableItems.includes(item.menuItemId)
        );
        if (!hasApplicableItem) return false;
    }

    // Check category restrictions
    if (this.applicableCategories.length > 0) {
        const hasApplicableCategory = items.some(item =>
            this.applicableCategories.includes(item.category)
        );
        if (!hasApplicableCategory) return false;
    }

    return true;
};

// Method to calculate discount amount
discountSchema.methods.calculateDiscount = function (orderValue) {
    let discountAmount = 0;

    if (this.type === 'percentage') {
        discountAmount = (orderValue * this.value) / 100;
        if (this.maxDiscount && discountAmount > this.maxDiscount) {
            discountAmount = this.maxDiscount;
        }
    } else if (this.type === 'fixed') {
        discountAmount = this.value;
    }

    return Math.min(discountAmount, orderValue);
};

module.exports = mongoose.model('Discount', discountSchema);
