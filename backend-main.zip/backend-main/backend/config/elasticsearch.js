const { Client } = require('@elastic/elasticsearch');

let esClient = null;

try {
    esClient = new Client({
        node: process.env.ELASTICSEARCH_URL || 'http://localhost:9200'
    });
} catch (error) {
    console.error('Elasticsearch initialization error:', error.message);
}

const connectElasticsearch = async () => {
    if (!esClient) {
        console.log('⚠️  Elasticsearch client not initialized - search will use MongoDB');
        return;
    }

    try {
        await esClient.ping();
        console.log('✅ Elasticsearch Connected');
    } catch (error) {
        console.error('⚠️  Could not connect to Elasticsearch - search will use MongoDB:', error.message);
    }
};

module.exports = { esClient, connectElasticsearch };
