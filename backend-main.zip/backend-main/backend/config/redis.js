const { createClient } = require('redis');

let redisClient = null;
let isRedisConnected = false;

try {
    redisClient = createClient({
        url: process.env.REDIS_URL || 'redis://localhost:6379',
        socket: {
            reconnectStrategy: (retries) => {
                if (retries > 5) {
                    console.log('❌ Redis: Max retries reached, stopping reconnection attempts.');
                    return new Error('Max retries reached');
                }
                return Math.min(retries * 100, 3000);
            }
        }
    });

    redisClient.on('error', (err) => {
        console.log('Redis Client Error:', err.message);
        isRedisConnected = false;
    });

    redisClient.on('connect', () => {
        console.log('✅ Redis Client Connected');
        isRedisConnected = true;
    });

    redisClient.on('end', () => {
        isRedisConnected = false;
    });
} catch (error) {
    console.error('Redis initialization error:', error.message);
}

const connectRedis = async () => {
    if (!redisClient) {
        console.log('⚠️  Redis client not initialized - caching disabled');
        return;
    }

    try {
        await redisClient.connect();
    } catch (error) {
        console.error('⚠️  Could not connect to Redis - caching disabled:', error.message);
    }
};

module.exports = { redisClient, connectRedis, isRedisConnected: () => isRedisConnected };
