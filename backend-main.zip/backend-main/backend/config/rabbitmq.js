const amqp = require('amqplib');
const { v4: uuidv4 } = require('uuid');

let channel = null;

const connectRabbitMQ = async () => {
    try {
        const connection = await amqp.connect(process.env.RABBITMQ_URL || 'amqp://guest:guest@localhost:5672');
        channel = await connection.createChannel();

        // Assert Celery queue
        await channel.assertQueue('celery', {
            durable: true,
            arguments: {
                'x-max-priority': 10
            }
        });

        console.log('✅ RabbitMQ Connected');
    } catch (error) {
        console.error('⚠️  Could not connect to RabbitMQ - background tasks disabled:', error.message);
    }
};

const publishToCelery = async (taskName, args = [], kwargs = {}) => {
    if (!channel) {
        console.log('⚠️  RabbitMQ not connected - task skipped:', taskName);
        return null;
    }

    const taskId = uuidv4();
    const message = {
        id: taskId,
        task: taskName,
        args: args,
        kwargs: kwargs,
        retries: 0,
        eta: null
    };

    const headers = {
        'content-type': 'application/json',
        'content-encoding': 'utf-8'
    };

    channel.sendToQueue('celery', Buffer.from(JSON.stringify(message)), {
        contentType: 'application/json',
        contentEncoding: 'utf-8',
        headers: headers,
        deliveryMode: 2 // Persistent
    });

    console.log(`Task ${taskName} published to Celery (ID: ${taskId})`);
    return taskId;
};

module.exports = { connectRabbitMQ, publishToCelery };
