const { uploadToCloudinary, deleteFromCloudinary } = require('../config/cloudinary');
const Restaurant = require('../models/Restaurant');
const MenuItem = require('../models/MenuItem');
const fs = require('fs').promises;

// @desc    Upload menu item image
// @route   POST /api/upload/menu-item
// @access  Private (restaurant)
exports.uploadMenuItemImage = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded',
            });
        }

        // Upload to Cloudinary
        const result = await uploadToCloudinary(req.file, 'delivr/menu-items');

        // Delete temporary file
        await fs.unlink(req.file.path);

        res.status(200).json({
            success: true,
            data: {
                url: result.url,
                publicId: result.publicId,
            },
        });
    } catch (error) {
        // Clean up temp file on error
        if (req.file?.path) {
            await fs.unlink(req.file.path).catch(() => { });
        }

        res.status(500).json({
            success: false,
            message: error.message || 'Failed to upload image',
        });
    }
};

// @desc    Upload restaurant image (logo/banner)
// @route   POST /api/upload/restaurant
// @access  Private (restaurant)
exports.uploadRestaurantImage = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded',
            });
        }

        const { type } = req.body; // 'logo' or 'banner'

        if (!type || !['logo', 'banner'].includes(type)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid image type. Must be "logo" or "banner"',
            });
        }

        // Upload to Cloudinary
        const result = await uploadToCloudinary(req.file, `delivr/restaurants/${type}`);

        // Delete temporary file
        await fs.unlink(req.file.path);

        // Update restaurant record
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (restaurant) {
            if (type === 'logo') {
                // Delete old logo from Cloudinary if exists
                if (restaurant.logo?.publicId) {
                    await deleteFromCloudinary(restaurant.logo.publicId).catch(() => { });
                }
                restaurant.logo = {
                    url: result.url,
                    publicId: result.publicId,
                };
            } else if (type === 'banner') {
                // Delete old banner from Cloudinary if exists
                if (restaurant.banner?.publicId) {
                    await deleteFromCloudinary(restaurant.banner.publicId).catch(() => { });
                }
                restaurant.banner = {
                    url: result.url,
                    publicId: result.publicId,
                };
            }

            await restaurant.save();
        }

        res.status(200).json({
            success: true,
            data: {
                url: result.url,
                publicId: result.publicId,
            },
        });
    } catch (error) {
        // Clean up temp file on error
        if (req.file?.path) {
            await fs.unlink(req.file.path).catch(() => { });
        }

        res.status(500).json({
            success: false,
            message: error.message || 'Failed to upload image',
        });
    }
};

// @desc    Delete image from Cloudinary
// @route   DELETE /api/upload/:publicId
// @access  Private (restaurant)
exports.deleteImage = async (req, res) => {
    try {
        const { publicId } = req.params;

        if (!publicId) {
            return res.status(400).json({
                success: false,
                message: 'Public ID is required',
            });
        }

        // Decode the publicId (may contain slashes)
        const decodedPublicId = decodeURIComponent(publicId);

        await deleteFromCloudinary(decodedPublicId);

        res.status(200).json({
            success: true,
            message: 'Image deleted successfully',
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to delete image',
        });
    }
};
