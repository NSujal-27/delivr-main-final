const Restaurant = require('../models/Restaurant');
const Order = require('../models/Order');
const MenuItem = require('../models/MenuItem');

// @desc    Get sales trends
// @route   GET /api/restaurant/analytics/sales-trends?period=week&compare=true
// @access  Private (restaurant)
exports.getSalesTrends = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { period = 'week', compare = 'false' } = req.query;
        const now = new Date();
        let startDate, endDate, compareStartDate, compareEndDate;

        // Determine period
        switch (period) {
            case 'day':
                startDate = new Date(now.setHours(0, 0, 0, 0));
                endDate = new Date(now.setHours(23, 59, 59, 999));
                if (compare === 'true') {
                    compareStartDate = new Date(startDate);
                    compareStartDate.setDate(compareStartDate.getDate() - 1);
                    compareEndDate = new Date(endDate);
                    compareEndDate.setDate(compareEndDate.getDate() - 1);
                }
                break;
            case 'week':
                startDate = new Date(now.setDate(now.getDate() - now.getDay()));
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                if (compare === 'true') {
                    compareStartDate = new Date(startDate);
                    compareStartDate.setDate(compareStartDate.getDate() - 7);
                    compareEndDate = new Date(endDate);
                    compareEndDate.setDate(compareEndDate.getDate() - 7);
                }
                break;
            case 'month':
                startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                endDate = new Date();
                if (compare === 'true') {
                    compareStartDate = new Date(startDate);
                    compareStartDate.setMonth(compareStartDate.getMonth() - 1);
                    compareEndDate = new Date(compareStartDate);
                    compareEndDate.setMonth(compareEndDate.getMonth() + 1);
                    compareEndDate.setDate(0);
                }
                break;
            case 'year':
                startDate = new Date(now.getFullYear(), 0, 1);
                endDate = new Date();
                if (compare === 'true') {
                    compareStartDate = new Date(startDate);
                    compareStartDate.setFullYear(compareStartDate.getFullYear() - 1);
                    compareEndDate = new Date(compareEndDate);
                    compareEndDate.setFullYear(compareEndDate.getFullYear() - 1);
                }
                break;
            default:
                startDate = new Date(now.setDate(now.getDate() - 7));
                endDate = new Date();
        }

        // Get current period orders
        const currentOrders = await Order.find({
            restaurantId: restaurant._id,
            status: 'delivered',
            createdAt: { $gte: startDate, $lte: endDate },
        });

        const currentRevenue = currentOrders.reduce((sum, order) => sum + order.totalAmount, 0);
        const currentOrderCount = currentOrders.length;
        const currentAvgOrderValue = currentOrderCount > 0 ? currentRevenue / currentOrderCount : 0;

        let comparison = null;

        // Get comparison period data if requested
        if (compare === 'true' && compareStartDate && compareEndDate) {
            const compareOrders = await Order.find({
                restaurantId: restaurant._id,
                status: 'delivered',
                createdAt: { $gte: compareStartDate, $lte: compareEndDate },
            });

            const compareRevenue = compareOrders.reduce((sum, order) => sum + order.totalAmount, 0);
            const compareOrderCount = compareOrders.length;

            const revenueChange = compareRevenue > 0 ? ((currentRevenue - compareRevenue) / compareRevenue) * 100 : 0;
            const orderCountChange = compareOrderCount > 0 ? ((currentOrderCount - compareOrderCount) / compareOrderCount) * 100 : 0;

            comparison = {
                previousRevenue: compareRevenue,
                previousOrderCount: compareOrderCount,
                revenueChange: revenueChange.toFixed(2),
                orderCountChange: orderCountChange.toFixed(2),
            };
        }

        // Daily breakdown for charts
        const dailyData = [];
        const dateMap = {};

        currentOrders.forEach((order) => {
            const date = order.createdAt.toISOString().split('T')[0];
            if (!dateMap[date]) {
                dateMap[date] = { date, revenue: 0, orders: 0 };
            }
            dateMap[date].revenue += order.totalAmount;
            dateMap[date].orders += 1;
        });

        Object.keys(dateMap).sort().forEach((date) => {
            dailyData.push(dateMap[date]);
        });

        res.status(200).json({
            success: true,
            data: {
                period,
                currentRevenue,
                currentOrderCount,
                currentAvgOrderValue,
                comparison,
                dailyData,
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get popular items analysis
// @route   GET /api/restaurant/analytics/popular-items?limit=10
// @access  Private (restaurant)
exports.getPopularItems = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { limit = 10, period = 'month' } = req.query;
        const now = new Date();
        let startDate;

        switch (period) {
            case 'week':
                startDate = new Date(now.setDate(now.getDate() - 7));
                break;
            case 'month':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            case 'year':
                startDate = new Date(now.setFullYear(now.getFullYear() - 1));
                break;
            default:
                startDate = new Date(now.setMonth(now.getMonth() - 1));
        }

        // Aggregate orders to find popular items
        const orders = await Order.find({
            restaurantId: restaurant._id,
            status: 'delivered',
            createdAt: { $gte: startDate },
        });

        const itemStats = {};

        orders.forEach((order) => {
            order.items?.forEach((item) => {
                const itemId = item.menuItemId?.toString() || item.name;
                if (!itemStats[itemId]) {
                    itemStats[itemId] = {
                        name: item.name,
                        orderCount: 0,
                        quantity: 0,
                        revenue: 0,
                    };
                }
                itemStats[itemId].orderCount += 1;
                itemStats[itemId].quantity += item.quantity;
                itemStats[itemId].revenue += item.price * item.quantity;
            });
        });

        const popularItems = Object.values(itemStats)
            .sort((a, b) => b.quantity - a.quantity)
            .slice(0, parseInt(limit));

        res.status(200).json({
            success: true,
            data: popularItems,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get peak hours analysis
// @route   GET /api/restaurant/analytics/peak-hours
// @access  Private (restaurant)
exports.getPeakHours = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { period = 'week' } = req.query;
        const now = new Date();
        let startDate;

        switch (period) {
            case 'week':
                startDate = new Date(now.setDate(now.getDate() - 7));
                break;
            case 'month':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            default:
                startDate = new Date(now.setDate(now.getDate() - 7));
        }

        const orders = await Order.find({
            restaurantId: restaurant._id,
            createdAt: { $gte: startDate },
        });

        const hourStats = Array(24).fill(0).map((_, i) => ({
            hour: i,
            orderCount: 0,
            revenue: 0,
        }));

        orders.forEach((order) => {
            const hour = new Date(order.createdAt).getHours();
            hourStats[hour].orderCount += 1;
            if (order.status === 'delivered') {
                hourStats[hour].revenue += order.totalAmount;
            }
        });

        // Find peak hours
        const peakHours = [...hourStats]
            .sort((a, b) => b.orderCount - a.orderCount)
            .slice(0, 5);

        res.status(200).json({
            success: true,
            data: {
                hourlyBreakdown: hourStats,
                peakHours,
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get customer insights
// @route   GET /api/restaurant/analytics/customer-insights
// @access  Private (restaurant)
exports.getCustomerInsights = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const orders = await Order.find({
            restaurantId: restaurant._id,
            status: 'delivered',
        }).populate('userId', 'name email');

        const customerStats = {};

        orders.forEach((order) => {
            const customerId = order.userId?._id?.toString();
            if (customerId) {
                if (!customerStats[customerId]) {
                    customerStats[customerId] = {
                        name: order.userId.name,
                        email: order.userId.email,
                        orderCount: 0,
                        totalSpent: 0,
                        lastOrder: order.createdAt,
                    };
                }
                customerStats[customerId].orderCount += 1;
                customerStats[customerId].totalSpent += order.totalAmount;
                if (order.createdAt > customerStats[customerId].lastOrder) {
                    customerStats[customerId].lastOrder = order.createdAt;
                }
            }
        });

        const totalCustomers = Object.keys(customerStats).length;
        const repeatCustomers = Object.values(customerStats).filter(
            (c) => c.orderCount > 1
        ).length;
        const repeatRate = totalCustomers > 0 ? (repeatCustomers / totalCustomers) * 100 : 0;

        const topCustomers = Object.values(customerStats)
            .sort((a, b) => b.totalSpent - a.totalSpent)
            .slice(0, 10);

        res.status(200).json({
            success: true,
            data: {
                totalCustomers,
                repeatCustomers,
                repeatRate: repeatRate.toFixed(2),
                topCustomers,
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get performance metrics
// @route   GET /api/restaurant/analytics/performance-metrics
// @access  Private (restaurant)
exports.getPerformanceMetrics = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const now = new Date();
        const monthAgo = new Date(now.setMonth(now.getMonth() - 1));

        const orders = await Order.find({
            restaurantId: restaurant._id,
            createdAt: { $gte: monthAgo },
        });

        const totalOrders = orders.length;
        const deliveredOrders = orders.filter((o) => o.status === 'delivered').length;
        const cancelledOrders = orders.filter((o) => o.status === 'cancelled').length;

        const fulfillmentRate = totalOrders > 0 ? (deliveredOrders / totalOrders) * 100 : 0;
        const cancellationRate = totalOrders > 0 ? (cancelledOrders / totalOrders) * 100 : 0;

        const avgRevenue = deliveredOrders > 0
            ? orders.filter((o) => o.status === 'delivered')
                .reduce((sum, o) => sum + o.totalAmount, 0) / deliveredOrders
            : 0;

        res.status(200).json({
            success: true,
            data: {
                totalOrders,
                deliveredOrders,
                cancelledOrders,
                fulfillmentRate: fulfillmentRate.toFixed(2),
                cancellationRate: cancellationRate.toFixed(2),
                avgOrderValue: avgRevenue.toFixed(2),
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};
