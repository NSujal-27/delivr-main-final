const Restaurant = require('../models/Restaurant');
const Notification = require('../models/Notification');

// @desc    Get all notifications for restaurant
// @route   GET /api/restaurant/notifications?page=1&limit=20&unreadOnly=false
// @access  Private (restaurant)
exports.getNotifications = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { page = 1, limit = 20, unreadOnly = 'false' } = req.query;

        let query = { restaurantId: restaurant._id };
        if (unreadOnly === 'true') {
            query.read = false;
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const notifications = await Notification.find(query)
            .sort({ createdAt: -1 })
            .limit(parseInt(limit))
            .skip(skip)
            .populate('orderId', 'orderId status totalAmount')
            .populate('ticketId', 'ticketId subject');

        const total = await Notification.countDocuments(query);

        res.status(200).json({
            success: true,
            count: notifications.length,
            total,
            totalPages: Math.ceil(total / parseInt(limit)),
            currentPage: parseInt(page),
            data: notifications,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get unread notification count
// @route   GET /api/restaurant/notifications/unread-count
// @access  Private (restaurant)
exports.getUnreadCount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const count = await Notification.countDocuments({
            restaurantId: restaurant._id,
            read: false,
        });

        res.status(200).json({
            success: true,
            count,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Mark notification as read
// @route   PUT /api/restaurant/notifications/:id/read
// @access  Private (restaurant)
exports.markAsRead = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const notification = await Notification.findById(req.params.id);

        if (!notification) {
            return res.status(404).json({
                success: false,
                message: 'Notification not found',
            });
        }

        // Verify notification belongs to this restaurant
        if (notification.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this notification',
            });
        }

        notification.read = true;
        await notification.save();

        res.status(200).json({
            success: true,
            data: notification,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Mark all notifications as read
// @route   PUT /api/restaurant/notifications/mark-all-read
// @access  Private (restaurant)
exports.markAllAsRead = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        await Notification.updateMany(
            { restaurantId: restaurant._id, read: false },
            { read: true }
        );

        res.status(200).json({
            success: true,
            message: 'All notifications marked as read',
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Delete a notification
// @route   DELETE /api/restaurant/notifications/:id
// @access  Private (restaurant)
exports.deleteNotification = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const notification = await Notification.findById(req.params.id);

        if (!notification) {
            return res.status(404).json({
                success: false,
                message: 'Notification not found',
            });
        }

        // Verify notification belongs to this restaurant
        if (notification.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to delete this notification',
            });
        }

        await notification.deleteOne();

        res.status(200).json({
            success: true,
            message: 'Notification deleted',
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Create a notification (internal use)
// @access  Internal
exports.createNotification = async (notificationData) => {
    try {
        const notification = await Notification.create(notificationData);
        return notification;
    } catch (error) {
        console.error('Error creating notification:', error);
        throw error;
    }
};
