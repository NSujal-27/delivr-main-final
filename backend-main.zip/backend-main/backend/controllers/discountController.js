const Restaurant = require('../models/Restaurant');
const Discount = require('../models/Discount');

// @desc    Create a new discount
// @route   POST /api/restaurant/discounts
// @access  Private (restaurant)
exports.createDiscount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const {
            code,
            description,
            type,
            value,
            minOrderValue,
            maxDiscount,
            validFrom,
            validUntil,
            usageLimit,
            applicableItems,
            applicableCategories,
        } = req.body;

        // Validate required fields
        if (!code || !description || !type || !value || !validFrom || !validUntil) {
            return res.status(400).json({
                success: false,
                message: 'Please provide all required fields',
            });
        }

        // Validate dates
        if (new Date(validFrom) >= new Date(validUntil)) {
            return res.status(400).json({
                success: false,
                message: 'Valid until date must be after valid from date',
            });
        }

        // Check if code already exists for this restaurant
        const existingDiscount = await Discount.findOne({
            restaurantId: restaurant._id,
            code: code.toUpperCase(),
        });

        if (existingDiscount) {
            return res.status(400).json({
                success: false,
                message: 'Discount code already exists',
            });
        }

        const discount = await Discount.create({
            restaurantId: restaurant._id,
            code: code.toUpperCase(),
            description,
            type,
            value,
            minOrderValue: minOrderValue || 0,
            maxDiscount,
            validFrom,
            validUntil,
            usageLimit,
            applicableItems: applicableItems || [],
            applicableCategories: applicableCategories || [],
            createdBy: req.user._id,
        });

        res.status(201).json({
            success: true,
            data: discount,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get all discounts for restaurant
// @route   GET /api/restaurant/discounts?active=true&page=1&limit=20
// @access  Private (restaurant)
exports.getDiscounts = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { active, page = 1, limit = 20 } = req.query;

        let query = { restaurantId: restaurant._id };

        if (active === 'true') {
            query.isActive = true;
        } else if (active === 'false') {
            query.isActive = false;
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const discounts = await Discount.find(query)
            .sort({ createdAt: -1 })
            .limit(parseInt(limit))
            .skip(skip);

        const total = await Discount.countDocuments(query);

        res.status(200).json({
            success: true,
            count: discounts.length,
            total,
            totalPages: Math.ceil(total / parseInt(limit)),
            currentPage: parseInt(page),
            data: discounts,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get single discount
// @route   GET /api/restaurant/discounts/:id
// @access  Private (restaurant)
exports.getDiscount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const discount = await Discount.findById(req.params.id);

        if (!discount) {
            return res.status(404).json({
                success: false,
                message: 'Discount not found',
            });
        }

        // Verify discount belongs to this restaurant
        if (discount.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to access this discount',
            });
        }

        res.status(200).json({
            success: true,
            data: discount,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update discount
// @route   PUT /api/restaurant/discounts/:id
// @access  Private (restaurant)
exports.updateDiscount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        let discount = await Discount.findById(req.params.id);

        if (!discount) {
            return res.status(404).json({
                success: false,
                message: 'Discount not found',
            });
        }

        // Verify discount belongs to this restaurant
        if (discount.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this discount',
            });
        }

        // Don't allow changing restaurant ID or used count
        const allowedUpdates = [
            'description',
            'type',
            'value',
            'minOrderValue',
            'maxDiscount',
            'validFrom',
            'validUntil',
            'usageLimit',
            'applicableItems',
            'applicableCategories',
            'isActive',
        ];

        const updates = {};
        Object.keys(req.body).forEach((key) => {
            if (allowedUpdates.includes(key)) {
                updates[key] = req.body[key];
            }
        });

        discount = await Discount.findByIdAndUpdate(req.params.id, updates, {
            new: true,
            runValidators: true,
        });

        res.status(200).json({
            success: true,
            data: discount,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Delete discount
// @route   DELETE /api/restaurant/discounts/:id
// @access  Private (restaurant)
exports.deleteDiscount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const discount = await Discount.findById(req.params.id);

        if (!discount) {
            return res.status(404).json({
                success: false,
                message: 'Discount not found',
            });
        }

        // Verify discount belongs to this restaurant
        if (discount.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to delete this discount',
            });
        }

        await discount.deleteOne();

        res.status(200).json({
            success: true,
            message: 'Discount deleted successfully',
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Toggle discount active status
// @route   PATCH /api/restaurant/discounts/:id/toggle
// @access  Private (restaurant)
exports.toggleDiscount = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const discount = await Discount.findById(req.params.id);

        if (!discount) {
            return res.status(404).json({
                success: false,
                message: 'Discount not found',
            });
        }

        // Verify discount belongs to this restaurant
        if (discount.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this discount',
            });
        }

        discount.isActive = !discount.isActive;
        await discount.save();

        res.status(200).json({
            success: true,
            data: discount,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get discount usage statistics
// @route   GET /api/restaurant/discounts/:id/stats
// @access  Private (restaurant)
exports.getDiscountStats = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const discount = await Discount.findById(req.params.id);

        if (!discount) {
            return res.status(404).json({
                success: false,
                message: 'Discount not found',
            });
        }

        // Verify discount belongs to this restaurant
        if (discount.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to access this discount',
            });
        }

        const stats = {
            code: discount.code,
            usedCount: discount.usedCount,
            usageLimit: discount.usageLimit,
            remainingUses: discount.usageLimit ? discount.usageLimit - discount.usedCount : null,
            usagePercentage: discount.usageLimit ? ((discount.usedCount / discount.usageLimit) * 100).toFixed(2) : null,
            isActive: discount.isActive,
            isCurrentlyValid: discount.isCurrentlyValid,
            validFrom: discount.validFrom,
            validUntil: discount.validUntil,
        };

        res.status(200).json({
            success: true,
            data: stats,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};
