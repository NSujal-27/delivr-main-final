const Restaurant = require('../models/Restaurant');
const MenuItem = require('../models/MenuItem');
const Order = require('../models/Order');

// @desc    Get restaurant profile for logged-in restaurant owner
// @route   GET /api/restaurant/profile
// @access  Private (restaurant)
exports.getProfile = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found for this user',
            });
        }

        res.status(200).json({
            success: true,
            data: restaurant,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update restaurant settings
// @route   PUT /api/restaurant/settings
// @access  Private (restaurant)
exports.updateSettings = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const {
            name,
            address,
            city,
            state,
            pincode,
            phone,
            email,
            operatingHours,
            deliveryRadius,
            bankInfo,
            taxInfo,
            contactMembers,
        } = req.body;

        // Update fields
        if (name) restaurant.name = name;
        if (address) restaurant.address = address;
        if (city) restaurant.city = city;
        if (state) restaurant.state = state;
        if (pincode) restaurant.pincode = pincode;
        if (phone) restaurant.phone = phone;
        if (email) restaurant.email = email;
        if (operatingHours) restaurant.operatingHours = operatingHours;
        if (deliveryRadius) restaurant.deliveryRadius = deliveryRadius;
        if (bankInfo) restaurant.bankInfo = bankInfo;
        if (taxInfo) restaurant.taxInfo = taxInfo;
        if (contactMembers) restaurant.contactMembers = contactMembers;

        await restaurant.save();

        res.status(200).json({
            success: true,
            data: restaurant,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get prep time configuration
// @route   GET /api/restaurant/prep-time
// @access  Private (restaurant)
exports.getPrepTime = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        res.status(200).json({
            success: true,
            data: restaurant.prepTime,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update prep time configuration
// @route   PUT /api/restaurant/prep-time
// @access  Private (restaurant)
exports.updatePrepTime = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        restaurant.prepTime = req.body;
        await restaurant.save();

        res.status(200).json({
            success: true,
            data: restaurant.prepTime,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get restaurant dashboard stats
// @route   GET /api/restaurant/dashboard
// @access  Private (restaurant)
exports.getDashboard = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Get today's stats
        const todayOrders = await Order.find({
            restaurantId: restaurant._id,
            createdAt: { $gte: today },
        });

        const activeOrders = await Order.find({
            restaurantId: restaurant._id,
            status: { $in: ['pending', 'confirmed', 'preparing', 'ready'] },
        });

        const todayRevenue = todayOrders.reduce(
            (sum, order) => sum + (order.status !== 'cancelled' ? order.totalAmount : 0),
            0
        );

        const totalOrders = await Order.countDocuments({
            restaurantId: restaurant._id,
        });

        const completedOrders = await Order.countDocuments({
            restaurantId: restaurant._id,
            status: 'delivered',
        });

        // Get recent orders
        const recentOrders = await Order.find({
            restaurantId: restaurant._id,
        })
            .populate('userId', 'name phone')
            .sort({ createdAt: -1 })
            .limit(5);

        res.status(200).json({
            success: true,
            data: {
                stats: {
                    todayOrders: todayOrders.length,
                    todayRevenue,
                    activeOrders: activeOrders.length,
                    totalOrders,
                    completedOrders,
                    avgRating: restaurant.avgRating,
                },
                recentOrders,
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get restaurant orders
// @route   GET /api/restaurant/orders?status=active|history|cancelled&page=1&limit=20&startDate=...&endDate=...
// @access  Private (restaurant)
exports.getOrders = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { status, page = 1, limit = 20, startDate, endDate, search } = req.query;
        let query = { restaurantId: restaurant._id };

        // Status filtering
        if (status === 'active') {
            query.status = { $in: ['pending', 'confirmed', 'preparing', 'ready', 'picked_up', 'out_for_delivery'] };
        } else if (status === 'history' || status === 'completed') {
            query.status = 'delivered';
        } else if (status === 'cancelled') {
            query.status = 'cancelled';
        }

        // Date range filtering
        if (startDate || endDate) {
            query.createdAt = {};
            if (startDate) {
                query.createdAt.$gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                query.createdAt.$lte = end;
            }
        }

        // Search by order ID or customer name
        if (search) {
            // This will require a text index or separate query
            query.orderId = { $regex: search, $options: 'i' };
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const orders = await Order.find(query)
            .populate('userId', 'name phone email')
            .populate('deliveryPartnerId', 'name phone')
            .sort({ createdAt: -1 })
            .limit(parseInt(limit))
            .skip(skip);

        const total = await Order.countDocuments(query);

        res.status(200).json({
            success: true,
            count: orders.length,
            total,
            totalPages: Math.ceil(total / parseInt(limit)),
            currentPage: parseInt(page),
            data: orders,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update order status
// @route   PUT /api/restaurant/orders/:id/status
// @access  Private (restaurant)
exports.updateOrderStatus = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const order = await Order.findById(req.params.id);

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found',
            });
        }

        // Verify order belongs to this restaurant
        if (order.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this order',
            });
        }

        const { status } = req.body;
        const validStatuses = ['confirmed', 'preparing', 'ready', 'cancelled'];

        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status',
            });
        }

        order.status = status;
        await order.save();

        res.status(200).json({
            success: true,
            data: order,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get menu items
// @route   GET /api/restaurant/menu
// @access  Private (restaurant)
exports.getMenu = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const menuItems = await MenuItem.find({ restaurantId: restaurant._id }).sort({ category: 1 });

        res.status(200).json({
            success: true,
            count: menuItems.length,
            data: menuItems,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Add menu item
// @route   POST /api/restaurant/menu
// @access  Private (restaurant)
exports.addMenuItem = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const menuItem = await MenuItem.create({
            ...req.body,
            restaurantId: restaurant._id,
        });

        res.status(201).json({
            success: true,
            data: menuItem,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update menu item
// @route   PUT /api/restaurant/menu/:id
// @access  Private (restaurant)
exports.updateMenuItem = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const menuItem = await MenuItem.findById(req.params.id);

        if (!menuItem) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found',
            });
        }

        // Verify menu item belongs to this restaurant
        if (menuItem.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this menu item',
            });
        }

        const updatedMenuItem = await MenuItem.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );

        res.status(200).json({
            success: true,
            data: updatedMenuItem,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Delete menu item
// @route   DELETE /api/restaurant/menu/:id
// @access  Private (restaurant)
exports.deleteMenuItem = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const menuItem = await MenuItem.findById(req.params.id);

        if (!menuItem) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found',
            });
        }

        // Verify menu item belongs to this restaurant
        if (menuItem.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to delete this menu item',
            });
        }

        await menuItem.deleteOne();

        res.status(200).json({
            success: true,
            message: 'Menu item deleted',
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Toggle menu item availability
// @route   PATCH /api/restaurant/menu/:id/availability
// @access  Private (restaurant)
exports.toggleAvailability = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const menuItem = await MenuItem.findById(req.params.id);

        if (!menuItem) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found',
            });
        }

        // Verify menu item belongs to this restaurant
        if (menuItem.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this menu item',
            });
        }

        menuItem.isAvailable = !menuItem.isAvailable;
        await menuItem.save();

        res.status(200).json({
            success: true,
            data: menuItem,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get earnings summary
// @route   GET /api/restaurant/earnings
// @access  Private (restaurant)
exports.getEarnings = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { startDate, endDate } = req.query;
        const query = {
            restaurantId: restaurant._id,
            status: 'delivered',
        };

        if (startDate && endDate) {
            query.createdAt = {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
            };
        }

        const orders = await Order.find(query);

        const totalEarnings = orders.reduce((sum, order) => sum + order.totalAmount, 0);
        const totalOrders = orders.length;
        const avgOrderValue = totalOrders > 0 ? totalEarnings / totalOrders : 0;

        // Calculate daily earnings
        const earningsByDate = {};
        orders.forEach((order) => {
            const date = order.createdAt.toISOString().split('T')[0];
            if (!earningsByDate[date]) {
                earningsByDate[date] = 0;
            }
            earningsByDate[date] += order.totalAmount;
        });

        res.status(200).json({
            success: true,
            data: {
                totalEarnings,
                totalOrders,
                avgOrderValue,
                earningsByDate,
            },
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get transaction history
// @route   GET /api/restaurant/transactions
// @access  Private (restaurant)
exports.getTransactions = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { page = 1, limit = 20 } = req.query;

        const transactions = await Order.find({
            restaurantId: restaurant._id,
            status: 'delivered',
        })
            .select('orderId totalAmount paymentMethod paymentStatus createdAt deliveredAt')
            .sort({ createdAt: -1 })
            .limit(limit * 1)
            .skip((page - 1) * limit);

        const totalTransactions = await Order.countDocuments({
            restaurantId: restaurant._id,
            status: 'delivered',
        });

        res.status(200).json({
            success: true,
            count: transactions.length,
            totalPages: Math.ceil(totalTransactions / limit),
            currentPage: parseInt(page),
            data: transactions,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};
