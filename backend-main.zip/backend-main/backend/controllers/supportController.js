const Restaurant = require('../models/Restaurant');
const Ticket = require('../models/Ticket');

// @desc    Create a new support ticket
// @route   POST /api/restaurant/support/tickets
// @access  Private (restaurant)
exports.createTicket = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { subject, description, category, priority } = req.body;

        if (!subject || !description) {
            return res.status(400).json({
                success: false,
                message: 'Subject and description are required',
            });
        }

        const ticket = await Ticket.create({
            restaurantId: restaurant._id,
            subject,
            description,
            category: category || 'general',
            priority: priority || 'medium',
        });

        res.status(201).json({
            success: true,
            data: ticket,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get all tickets for restaurant
// @route   GET /api/restaurant/support/tickets?status=open&page=1&limit=20
// @access  Private (restaurant)
exports.getTickets = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const { status, category, priority, page = 1, limit = 20 } = req.query;

        let query = { restaurantId: restaurant._id };

        if (status) query.status = status;
        if (category) query.category = category;
        if (priority) query.priority = priority;

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const tickets = await Ticket.find(query)
            .sort({ createdAt: -1 })
            .limit(parseInt(limit))
            .skip(skip);

        const total = await Ticket.countDocuments(query);

        res.status(200).json({
            success: true,
            count: tickets.length,
            total,
            totalPages: Math.ceil(total / parseInt(limit)),
            currentPage: parseInt(page),
            data: tickets,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Get a single ticket
// @route   GET /api/restaurant/support/tickets/:id
// @access  Private (restaurant)
exports.getTicket = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const ticket = await Ticket.findById(req.params.id);

        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Ticket not found',
            });
        }

        // Verify ticket belongs to this restaurant
        if (ticket.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to view this ticket',
            });
        }

        res.status(200).json({
            success: true,
            data: ticket,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Update a ticket
// @route   PUT /api/restaurant/support/tickets/:id
// @access  Private (restaurant)
exports.updateTicket = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const ticket = await Ticket.findById(req.params.id);

        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Ticket not found',
            });
        }

        // Verify ticket belongs to this restaurant
        if (ticket.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this ticket',
            });
        }

        const { status, priority } = req.body;

        if (status) ticket.status = status;
        if (priority) ticket.priority = priority;

        if (status === 'resolved' && !ticket.resolvedAt) {
            ticket.resolvedAt = new Date();
        }

        if (status === 'closed' && !ticket.closedAt) {
            ticket.closedAt = new Date();
        }

        await ticket.save();

        res.status(200).json({
            success: true,
            data: ticket,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// @desc    Add a reply to a ticket
// @route   POST /api/restaurant/support/tickets/:id/reply
// @access  Private (restaurant)
exports.addReply = async (req, res) => {
    try {
        const restaurant = await Restaurant.findOne({ userId: req.user._id });

        if (!restaurant) {
            return res.status(404).json({
                success: false,
                message: 'Restaurant not found',
            });
        }

        const ticket = await Ticket.findById(req.params.id);

        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Ticket not found',
            });
        }

        // Verify ticket belongs to this restaurant
        if (ticket.restaurantId.toString() !== restaurant._id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to reply to this ticket',
            });
        }

        const { message } = req.body;

        if (!message) {
            return res.status(400).json({
                success: false,
                message: 'Message is required',
            });
        }

        ticket.replies.push({
            from: 'restaurant',
            message,
            timestamp: new Date(),
        });

        // Update status to waiting-response if it was resolved
        if (ticket.status === 'resolved' || ticket.status === 'closed') {
            ticket.status = 'waiting-response';
        }

        await ticket.save();

        res.status(200).json({
            success: true,
            data: ticket,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};
